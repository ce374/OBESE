# Kaycyy — Discography Index

Complete discography of **KayCyy** (KayCyy Pluto), compiled from iTunes, lrclib, and MusicBrainz.

- **Releases (Kaycyy-led):** 9
- **Features:** 24
- **Total tracks:** 58

## Releases

### With You - Single
- Artist: KayCyy
- Released: 2017-02-19
- Genre: Afro-Pop
- Tracks: 1
  - With You

### TW20 50 - Single
- Artist: KayCyy
- Released: 2022-03-11
- Genre: Hip-Hop/Rap
- Tracks: 2
  - THE SUN (Prod. Gesaffelstein)
  - LOVE & HATE (Prod. Gesaffelstein)

### TW2052
- Artist: KayCyy
- Released: 2022-03-11
- Genre: Hip-Hop/Rap
- Tracks: 4
  - ASHLEY'S HEARTBEAT (Prod. Gesaffelstein)
  - TIMELESS (Prod. Gesaffelstein)
  - THE SUN (Prod. Gesaffelstein)
  - LOVE & HATE (Prod. Gesaffelstein)

### Get Used To It
- Artist: KayCyy
- Released: 2022-06-02
- Genre: Hip-Hop/Rap
- Tracks: 3
  - Replay
  - Shoutouts
  - Hold You Up

### Who Else Would It Be - Single
- Artist: KayCyy
- Released: 2022-11-11
- Genre: Hip-Hop/Rap
- Tracks: 1
  - Who Else Would It Be

### Higher (feat. FFY) - Single
- Artist: KayCyy, EchoSlim & Nicko Rebel
- Released: 2023-07-27
- Genre: Modern Dancehall
- Tracks: 1
  - Higher (feat. FFY)

### My Jeans - Single
- Artist: KayCyy
- Released: 2023-08-04
- Genre: Hip-Hop/Rap
- Tracks: 1
  - My Jeans

### Dear Darlin - Single
- Artist: KayCyy Pluto
- Released: 2025-02-28
- Genre: Country
- Tracks: 1
  - Dear Darlin

### FAR AWAY - Single
- Artist: KayCyy
- Released: 2025-09-05
- Genre: Afro-Beat
- Tracks: 2
  - FAR AWAY
  - SEND WAVE

## Features

### Behind These Scars
- Artist: Casanova
- Released: 2019-10-11
- Tracks (with Kaycyy): 1
  - Could’ve Been Somethin’ (feat. Kaycyy Pluto) — Casanova

### B.I.B.L.E.
- Artist: Fivio Foreign
- Released: 2022-04-08
- Tracks (with Kaycyy): 2
  - On God (feat. KayCyy) — Fivio Foreign
  - Hello (feat. Chlöe & KayCyy) — Fivio Foreign

### B.I.B.L.E.
- Artist: Fivio Foreign
- Released: 2022-04-08
- Tracks (with Kaycyy): 2
  - On God (feat. KayCyy) — Fivio Foreign
  - Hello (feat. Chlöe & KayCyy) — Fivio Foreign

### WDYWTBWYGU
- Artist: johan lenox
- Released: 2022-05-13
- Tracks (with Kaycyy): 1
  - What Happening — johan lenox, KayCyy & Brooklyn Youth Chorus

### Chamber WDYWTBWYGU
- Artist: johan lenox
- Released: 2023-02-10
- Tracks (with Kaycyy): 1
  - What Happening (Chamber Version) — johan lenox, KayCyy & Brooklyn Youth Chorus

### Keed Talk To ‘Em 2
- Artist: Lil Keed
- Released: 2023-03-17
- Tracks (with Kaycyy): 1
  - Can't Fall Victim (feat. KayCyy) — Lil Keed

### Tarzana
- Artist: Purple Tears
- Released: 2023-04-21
- Tracks (with Kaycyy): 1
  - Tough Love (feat. Murda Beatz and KayCyy) — Purple Tears

### Popstar Degenerate
- Artist: Ghostluvme
- Released: 2023-08-04
- Tracks (with Kaycyy): 1
  - Like I thought — Ghostluvme & KayCyy

### Humble Soles
- Artist: Humble Soles, DJ Clue & RJAE
- Released: 2023-08-10
- Tracks (with Kaycyy): 1
  - Stuck In LA — Humble Soles, KayCyy, Reuben Vincent, Guapdad 4000 & Ambré

### LUCY
- Artist: BKTHERULA
- Released: 2024-03-15
- Tracks (with Kaycyy): 1
  - EUPHORIA — BKTHERULA, Joey Bada$$, Murda Beatz & KayCyy

### There's A Way (feat. KayCyy) - Single
- Artist: Dina Ayada
- Released: 2024-05-31
- Tracks (with Kaycyy): 3
  - There's A Way (feat. KayCyy) — Dina Ayada
  - Hummer — Dina Ayada
  - 100 Bands — Dina Ayada

### The Script
- Artist: Dina Ayada
- Released: 2024-05-31
- Tracks (with Kaycyy): 1
  - There's a Way (feat. KayCyy) — Dina Ayada

### There's a Way (feat. KayCyy) - Single
- Artist: Dina Ayada
- Released: 2024-05-31
- Tracks (with Kaycyy): 3
  - There's a Way (feat. KayCyy) — Dina Ayada
  - Hummer — Dina Ayada
  - 100 Bands — Dina Ayada

### SADDEST TRUTH
- Artist: sign crushes motorist & KayCyy
- Released: 2024-09-27
- Tracks (with Kaycyy): 6
  - SLÁINTE — sign crushes motorist & KayCyy
  - Nyumbani (Sounds Like) — sign crushes motorist & KayCyy
  - My Heart is (feat. Khal!l) — sign crushes motorist & KayCyy
  - Never Wanna See You — sign crushes motorist & KayCyy
  - Carry On — sign crushes motorist & KayCyy
  - Green Trees (feat. Brinx Parker & johan lenox) — sign crushes motorist & KayCyy

### I Can't Complain (feat. KayCyy) - Single
- Artist: Daquon Curtis
- Released: 2024-12-06
- Tracks (with Kaycyy): 1
  - I Can't Complain (feat. KayCyy) — Daquon Curtis

### INTERSTELLAR
- Artist: MDJ! & 500k
- Released: 2025-03-15
- Tracks (with Kaycyy): 1
  - SUGAR&SPICE (feat. KayCyy Pluto) — MDJ!, 500k & nicky

### SADDEST TRUTH
- Artist: sign crushes motorist & KayCyy
- Released: 2025-04-11
- Tracks (with Kaycyy): 7
  - SLÁINTE — sign crushes motorist & KayCyy
  - Diamonds — sign crushes motorist & KayCyy
  - Nyumbani (Sounds Like) — sign crushes motorist & KayCyy
  - My Heart is (feat. Khal!l & China) — sign crushes motorist & KayCyy
  - Never Wanna See You — sign crushes motorist & KayCyy
  - Carry On — sign crushes motorist & KayCyy
  - Green Trees (feat. Brinx Parker & johan lenox) — sign crushes motorist & KayCyy

### Eclipse feat. KayCyy - Single
- Artist: johan lenox & KayCyy
- Released: 2025-06-06
- Tracks (with Kaycyy): 1
  - Eclipse feat. KayCyy — johan lenox & KayCyy

### pressure remix / he knows us all (feat. KayCyy) - Single
- Artist: MDJ!
- Released: 2025-07-15
- Tracks (with Kaycyy): 1
  - trying to work (feat. KayCyy Pluto) — MDJ!

### purple hearts
- Artist: MDJ!
- Released: 2025-07-15
- Tracks (with Kaycyy): 2
  - trying to work (feat. KayCyy Pluto) — MDJ!
  - night out (feat. kkazie & KayCyy Pluto) — MDJ! & RAPT0R

### purple hearts starter pack - EP
- Artist: MDJ!
- Released: 2025-07-15
- Tracks (with Kaycyy): 1
  - trying to work (feat. KayCyy Pluto) — MDJ!

### trying to work (feat. KayCyy Pluto) - Single
- Artist: MDJ!
- Released: 2025-07-15
- Tracks (with Kaycyy): 1
  - trying to work (feat. KayCyy Pluto) — MDJ!

### Full Speed Nowhere
- Artist: johan lenox
- Released: 2025-10-31
- Tracks (with Kaycyy): 1
  - Eclipse — johan lenox & KayCyy

### Full Speed Nowhere (Chamber Version)
- Artist: johan lenox
- Released: 2026-10-30
- Tracks (with Kaycyy): 1
  - Eclipse — johan lenox & KayCyy

