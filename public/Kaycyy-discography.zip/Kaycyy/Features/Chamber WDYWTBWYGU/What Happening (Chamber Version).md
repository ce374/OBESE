# What Happening (Chamber Version)

![artwork](Assets/Images/chamber-wdywtbwygu-cover.jpg)

- **Album:** Chamber WDYWTBWYGU
- **Artist(s):** johan lenox, KayCyy & Brooklyn Youth Chorus
- **Album artist:** johan lenox
- **Released:** 2023-02-10
- **Duration:** 2:59
- **Genre:** Alternative

## Credits

- Performing artist: johan lenox, KayCyy & Brooklyn Youth Chorus
- Album artist: johan lenox

## Preview

![30-second preview](Assets/Audio/what-happening-chamber-version-chamber-wdywtbwygu-preview.m4a)

## Lyrics

_Lyrics not available._

