# Popstar Degenerate

![cover](Assets/Images/popstar-degenerate-cover.jpg)

- **Artist:** Ghostluvme
- **Type:** Feature
- **Released:** 2023-08-04
- **Genre:** Hip-Hop/Rap
- **Tracks:** 1

## Track listing

1. Like I thought — 2:45
