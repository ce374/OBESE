# Like I thought

![artwork](Assets/Images/popstar-degenerate-cover.jpg)

- **Album:** Popstar Degenerate
- **Artist(s):** Ghostluvme & KayCyy
- **Album artist:** Ghostluvme
- **Released:** 2023-08-04
- **Duration:** 2:45
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: Ghostluvme & KayCyy
- Album artist: Ghostluvme

## Preview

![30-second preview](Assets/Audio/like-i-thought-popstar-degenerate-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/like-i-thought-popstar-degenerate-lyrics.txt](Assets/Documents/like-i-thought-popstar-degenerate-lyrics.txt)

```
Tonight, I swear to god Ima kill myself

My heart is yours to do whatever you want
Oh shit, I used that same lyric before
You don't know how much you mean to me
Oh shit, I just fucking did it again

I can't talk to your parents
Without getting drunk first
I'm still the awkward asshole
As I have always been

I'm falling apart
I'm falling apart
I'm breaking down
I'm breaking down
This is what I've always been
Crawling on my knees
Trying to keep away
I'm wasting away

Tonight, I swear to god Ima kill myself
```

