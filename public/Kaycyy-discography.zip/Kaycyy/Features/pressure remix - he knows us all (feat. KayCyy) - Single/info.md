# pressure remix / he knows us all (feat. KayCyy) - Single

![cover](Assets/Images/pressure-remix-he-knows-us-all-feat-kaycyy---single-cover.jpg)

- **Artist:** MDJ!
- **Type:** Feature
- **Released:** 2025-07-15
- **Genre:** R&B/Soul
- **Tracks:** 1

## Track listing

1. trying to work (feat. KayCyy Pluto) — 3:27
