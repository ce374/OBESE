# EUPHORIA

![artwork](Assets/Images/lucy-cover.jpg)

- **Album:** LUCY
- **Artist(s):** BKTHERULA, Joey Bada$$, Murda Beatz & KayCyy
- **Album artist:** BKTHERULA
- **Released:** 2024-03-15
- **Duration:** 4:11
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: BKTHERULA, Joey Bada$$, Murda Beatz & KayCyy
- Album artist: BKTHERULA

## Preview

![30-second preview](Assets/Audio/euphoria-lucy-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/euphoria-lucy-lyrics.txt](Assets/Documents/euphoria-lucy-lyrics.txt)

```
You got me
You, yeah, oh
You got me when the stars start to align, uh-huh
You got me
You (Yeah, yeah, yeah, yeah)
Got me out my mind, yeah, yeah, yeah
You got me when the stars start to align, uh-huh

Feels just like it should
Sometimes we all misunderstood
I know you tried and gave it all

How you survive? We'll never know
Don't stoop too low, oh
Don't stoop too low, oh
Won't wear you down, yeah
Won't wear you down, oh
Won't, won't, won't
Won't wear you down
Be the first to let you know, first to let you go

You crossed the line too many times, yeah, of course it's personal
And you know I won't wear you
Of course (Of course)
Of course you seen before (Uh-huh)
Prayers for the soul (Uh-huh)
Spirit made of gold (Uh-huh)
Comfortable as I go (Yeah)
That's every area code (Uh-huh)
Ensure there's safety on your road, uh-huh
And you know I won't wear you down

Won't wear you down

Don't stoop too low
Won't wear you down, yeah

Won't wear you down
Won't, won't, won't

You got me
You, yeah, oh
You got me when the stars start to align, uh-huh
You got me
You (Yeah, yeah, yeah, yeah)
Got me out my mind, yeah, yeah, yeah
You got me when the stars start to align, uh-huh

I just got a new fling, my old thing just got a stingray

I ain't playin' no games, baby, tryna make you my main bitch

Girl, I got you jacked on my slang, now you talkin' my language
Even got you rockin' my chain, this a whole 'nother gang shit
Ooh, you got a pretty face, baby, I just wanna peep it
Before we get it really wavy, got me feelin' all silly
Raging, euphoric, gettin' on it
You wanna ride, baby, let's make a run for it
Hop on the plane, go to Hanoi
The world is yours, we can explore it
It's another ghetto love story

Penthouse on the top story
I ain't even gotta ask you for it
She just bust it open and pop it for me
Damn, shorty, it's finger lickin' like tandoori
And she give me that good brain like she graduated from a Montessori

I might just have to pull the drop out
Baby girl, tell me if you ridin'
Late night shift, we can pop out, no destination, we just vibin'
Got me tranced out in euphoria like I'm trippin' on psilocybin
Love the way our worlds collide and, pearly
Rockin' out 'til the end of time because

You got me
You, yeah, oh
You got me when the stars start to align, uh-huh
You got me
You (Yeah, yeah, yeah, yeah)
Got me out my mind, yeah, yeah, yeah
You got me when the stars start to align, uh-huh
```

