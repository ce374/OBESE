# LUCY

![cover](Assets/Images/lucy-cover.jpg)

- **Artist:** BKTHERULA
- **Type:** Feature
- **Released:** 2024-03-15
- **Genre:** Hip-Hop/Rap
- **Tracks:** 1

## Track listing

1. EUPHORIA — 4:11
