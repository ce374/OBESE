# trying to work (feat. KayCyy Pluto) - Single

![cover](Assets/Images/trying-to-work-feat-kaycyy-pluto---single-cover.jpg)

- **Artist:** MDJ!
- **Type:** Feature
- **Released:** 2025-07-15
- **Genre:** R&B/Soul
- **Tracks:** 1

## Track listing

1. trying to work (feat. KayCyy Pluto) — 3:27
