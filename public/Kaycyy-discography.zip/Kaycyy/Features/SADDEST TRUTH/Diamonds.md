# Diamonds

![artwork](Assets/Images/saddest-truth-cover.jpg)

- **Album:** SADDEST TRUTH
- **Artist(s):** sign crushes motorist & KayCyy
- **Released:** 2025-04-11
- **Duration:** 2:17
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: sign crushes motorist & KayCyy
- performance: Diamonds

## Preview

![30-second preview](Assets/Audio/diamonds-saddest-truth-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/diamonds-saddest-truth-lyrics.txt](Assets/Documents/diamonds-saddest-truth-lyrics.txt)

```
A man's word is the only thing left to stand on
For a moment of truth
Please bow your head and just say something
Amen
You gotta believe before you say
Amen
I think like twice in my life I got saved
Praise God
And that's just not enough
Please, Lord
Sometimes when I'm sad I smile, and when I'm happy I frown
They wouldn't know Lord, but um- You know
The gift is here and it's truly pure
Let's use our voice for good and not bad
Hyper, hyper, hyper, hyper, hyper
Now it's feeling young again
Finally feel like I can heal on my own again
Yeah
Heal on my own again
Yeah
We're dancing on quicksand
Don't know how we never sank
Two people can rob the bank
Two people can rob the bank
Yeah
Seem like you've been in and out
Yeah
Too old to be wrong again
Is this how the...
Yeah
Is this how the story ends?
Hate me, I'll still hold your hand
Seem like you've been born again
Who says?
Yeah
Who says that we can't change?
Finally feel like I can
Thank God you pregnant again
A new life is in your hands
God's on my side
God's on my, God's on my...
I sing like I'm not
I sing like I'm Stevie
Sing like I'm blind
Diamond in the rough
I dug till my fingers broke
Diamond in the rough
I dug till my fingers broke
Diamond in the rough
I dug till my fingers broke
Diamond in the rough
Can't say I'm not in love
Can't tell me I'm not in love
Can't tell me I'm not in love
Don't tell me I'm not in love
```

