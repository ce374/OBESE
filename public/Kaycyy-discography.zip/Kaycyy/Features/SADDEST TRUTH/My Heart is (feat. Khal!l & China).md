# My Heart is (feat. Khal!l & China)

![artwork](Assets/Images/saddest-truth-cover.jpg)

- **Album:** SADDEST TRUTH
- **Artist(s):** sign crushes motorist & KayCyy
- **Released:** 2025-04-11
- **Duration:** 4:34
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: sign crushes motorist & KayCyy
- performance: My Heart is

## Preview

![30-second preview](Assets/Audio/my-heart-is-feat-khall-china-saddest-truth-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/my-heart-is-feat-khall-china-saddest-truth-lyrics.txt](Assets/Documents/my-heart-is-feat-khall-china-saddest-truth-lyrics.txt)

```
Oh, you get cool points, you got swag just like me
Or you get a new purse courtesy at night three
New place on Earth, plant your feet, you never leave
New place on Earth, plant your feet, you get a seed

Trust the process and we gon' be rich forever, babe
This homemade, picked from the tree, this that lemonade
This that I'm nervous to lose you, baby, like my first chain
This that I'm furthest to get you, baby, I'm in a maze, oh

It's that I hate you, I miss you, I need you
Can't live without you, can't live without you, oh, yeah
Can't live without you, oh, yeah
I can't live without you
I can't live without you, I can't
I can't, I can't, oh I can't, oh I can't

Imagine a future with my family
Run away much longer

And my heart is crying out for love
And my heart is waiting to be broken
Yeah, you are
You're the air that I breathe
And you are
Everything I need, I can

So why don't you come around, and
Give me something, I've been
You sure you know, I've been
Cut short, I've been
Torn up, I've been
Demons try to rip it (whoo)
I've had help and I ain't fight back

If it ain't right, if it ain't right
If it ain't right (never don't break, never)
Why is it? (Yeah)
If it ain't right (never don't break, never), if it ain't right (never)

Spend time, pressure people to love
It's your choice, do whatever you want
How much is your rent? 'Cause I can chip in as much
She got ice on her wrist, already I sound dumb
She said, "It's my other gift that really makes me the one"

We shared a beer, we kiss when we on
We shared a beer, we kiss, but we never tell
We never, bam, bam, bam, bam
Never fucking write yours
I'm afraid of this and I'm
What's the errors? Tell me who made a mess of you
Direct contact, make sure you get the message

Then we right back to that question
Then we right back to that question
Then we right back to that question
Tell me, bam, bam, bam, bam
But never, tell me
Never fucking write, come on here, tell me
Mm-mm
Better fair life
```

