# Never Wanna See You

![artwork](Assets/Images/saddest-truth-cover.jpg)

- **Album:** SADDEST TRUTH
- **Artist(s):** sign crushes motorist & KayCyy
- **Released:** 2024-09-27
- **Duration:** 2:50
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: sign crushes motorist & KayCyy

## Preview

![30-second preview](Assets/Audio/never-wanna-see-you-saddest-truth-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/never-wanna-see-you-saddest-truth-lyrics.txt](Assets/Documents/never-wanna-see-you-saddest-truth-lyrics.txt)

```
Oh-oh-oh, oh-oh-oh, oh
Oh (oh)

Never wanna see you (voice inside of my head)
Never wanna watch you go
Standing on the sideline
Crying on the FaceTime
Never wanna see you
Never wanna hear your name (I don't, uh)
I was a beginner
Lord, she's just a sinner

That voice, that voice
That voice inside of my head (ooh)
That voice inside of my head
That keep on replaying everything that you said
Did you get happiness from the bread?
Did you save all the kids from the dark?
Staring in the moonlight, yeah

Did I hold all my silly remarks?
One day, for the B-day, it's there
Every day is your birthday instead (ooh)
Understand me, you know I shut down
Stuck inside a twilight
Try my hardest to always hold it
You're hopin' for a new life
Try my hardest, I'm holding you

Never wanna see you
Never, never
Standing in my door at night
Talking to the moonlight
Praying for a sunrise

Voice, that voice
That voice inside of her head
Yeah, that voice inside of her head
Is you still gettin' drunk off of pity
Is the label not making it easy?
I'm right here, you don't need to shrink
Dirty dishes is out of the sink
Heart froze, I'll buy you a mink

Never wanna see you
She said, "Too bad 'cause I wanna link"
Give you your flowers 'fore you could blink (nothing to say)
Bring you a crowd so you could sing (nothing to say)
I call you wild, you call me insane (sane, sane, sane-)
```

