# Green Trees (feat. Brinx Parker & johan lenox)

![artwork](Assets/Images/saddest-truth-cover.jpg)

- **Album:** SADDEST TRUTH
- **Artist(s):** sign crushes motorist & KayCyy
- **Released:** 2025-04-11
- **Duration:** 3:36
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: sign crushes motorist & KayCyy
- performance: Green Trees

## Preview

![30-second preview](Assets/Audio/green-trees-feat-brinx-parker-johan-lenox-saddest-truth-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/green-trees-feat-brinx-parker-johan-lenox-saddest-truth-lyrics.txt](Assets/Documents/green-trees-feat-brinx-parker-johan-lenox-saddest-truth-lyrics.txt)

```
Ooh (ooh)
Ooh
Ooh (ooh)

Green trees, blue sky found us
Green trees, blue sky found us
I look for your touch, for your touch
You know the time's up, the time up's and-
Green trees, blue sky found us
This joint, blue sky found us
Wake up, I look for your touch
Wake up, you know the time's up and-

Green trees, blue sky found us
Green trees, blue sky found us
I look for your touch, for your touch
I know the time's up, the time up's and-
Green trees, blue sky found us
Green trees, blue sky found us
I look for your touch, for your touch
You know the time's up, time's up

I look, I look
I look, oh, I look, oh, I look, I-I
Yeah-yeah, yeah
I look like I been searchin' for years, but still ain't findin'
Sit and wait for perfect, guess I got the worst assignment
We been workin' on honesty, you got better at lyin'
Reverse psychology, guess you learned from the-, uh

Guess you learned from the finest
When the wine's spilled in the sunrise, hope you move from the crisis
It's not news, baby, it's not news, but you fight it
When I'm done, every day, butterfly grew where you-
Grew where you standin'

Green trees, blue sky found us
Green trees, blue sky found us (yeah)
I look for your touch, for your touch (I-I look, I look)
You know the time's up, the time up's and- (yeah-yeah)
Green trees (yeah), blue sky found us
This joint, blue sky found us
Wake up, I look for your touch (yeah)
Wake up, you know the time's up and-

Green trees and blue skies, they weren't enough
You have to say you fell out of love
Out of love
Green trees and a new guy, it's getting tough
To see through a new light, I'm still in love
I'm still in love

Green trees, blue sky found us
Green trees, blue sky found us
I look for your touch, for your touch
I know the time's up, the time up's and-
Green trees, blue sky found us
Green trees, blue sky found us
I look for your touch, for your touch
You know the time's up, the time's up

Green trees, blue sky found us
Green trees, blue sky found us
I look for your touch, for your touch
You know the time's up, the time up's and
```

