# Carry On

![artwork](Assets/Images/saddest-truth-cover.jpg)

- **Album:** SADDEST TRUTH
- **Artist(s):** sign crushes motorist & KayCyy
- **Released:** 2025-04-11
- **Duration:** 2:07
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: sign crushes motorist & KayCyy
- performance: Carry On

## Preview

![30-second preview](Assets/Audio/carry-on-saddest-truth-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/carry-on-saddest-truth-lyrics.txt](Assets/Documents/carry-on-saddest-truth-lyrics.txt)

```
Don't, don't, no danger
Don't, don't, no danger

No danger in his own life, let it out
You say to go back home, I'm pulling up
It feels like I gave more than enough
But through your eyes
I walked you to your door, I was your crush
You tried to fall, but damn, I picked you up
I loved you, how could you call me a crush?
I loved you, how could you call me a friend?

I'm falling right on, love, babe
Feels like I gave you more
The grudges that we held didn't do
More
The chip upon my shoulder don't break
More, more, more than me now

It feels like it's not a good go
That baggage that you carry on your own
Baby, please just try and let them go
Please, I don't want to be alone
But I don't want to be alone
```

