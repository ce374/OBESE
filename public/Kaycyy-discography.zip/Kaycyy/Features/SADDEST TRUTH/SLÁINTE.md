# SLÁINTE

![artwork](Assets/Images/saddest-truth-cover.jpg)

- **Album:** SADDEST TRUTH
- **Artist(s):** sign crushes motorist & KayCyy
- **Released:** 2025-04-11
- **Duration:** 2:25
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: sign crushes motorist & KayCyy

## Preview

![30-second preview](Assets/Audio/slainte-saddest-truth-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/slainte-saddest-truth-lyrics.txt](Assets/Documents/slainte-saddest-truth-lyrics.txt)

```
It is with my deepest love, with absolute respect
That you will be in total harmony
(Let me see)
That you will be in total harmony
(What you about to hear)

Guide me on my path
Help me find my way
(What you about to hear)
Guide me on the road
(What you about to hear)
Let me find my place (oh-ah)

Ha-ha-ha-ha (ha-ha, ha-ha-ha)
Ha-ha-ha-ha, ha-ha

I said, let me find out, let me find out, oh
(What you about to hear) oh yeah, oh yeah
(On some audio ducking)
(Ha-ha-ha-ha, ha-ha) oh yeah, oh yeah
Let me find my place (let me find out, let me find)
(What you about to hear)

I stay on this better, this is like a winning trophy, you try forever
This is like ten thousand moments piled together
This is for the dreams that broke, thank God it's working
And this is for the kids still broke, karma's working
And who gon' say they saw this first? A bigger person
I wonder who gon' find my heart, my soul been searching
I fell too fast, just like my career, I'm back with purpose
I'm back with, uh

I talked to the Lord, most of y'all can't even get that service
(What you about to hear) uh
What you're listening to here, it's blood, sweat, and tears
Ten years, can you tell me what's fear?

Saddest (let me find out)
It's the saddest
Help me find my way (let me find my way)
(Let me find out) oh
Oh, yeah (let me find out)
(Sad...)
```

