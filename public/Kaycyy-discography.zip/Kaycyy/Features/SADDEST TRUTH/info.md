# SADDEST TRUTH

![cover](Assets/Images/saddest-truth-cover.jpg)

- **Artist:** sign crushes motorist & KayCyy
- **Type:** Feature
- **Released:** 2024-09-27
- **Genre:** Hip-Hop/Rap
- **Tracks:** 6

## Track listing

1. SLÁINTE — 2:25
2. Nyumbani (Sounds Like) — 2:32
3. My Heart is (feat. Khal!l) — 4:34
4. Never Wanna See You — 2:50
5. Carry On — 2:07
6. Green Trees (feat. Brinx Parker & johan lenox) — 3:36
