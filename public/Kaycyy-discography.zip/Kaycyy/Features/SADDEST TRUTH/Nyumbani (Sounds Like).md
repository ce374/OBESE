# Nyumbani (Sounds Like)

![artwork](Assets/Images/saddest-truth-cover.jpg)

- **Album:** SADDEST TRUTH
- **Artist(s):** sign crushes motorist & KayCyy
- **Released:** 2024-12-13
- **Duration:** 2:32
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: sign crushes motorist & KayCyy
- performance: Nyumbani (Sounds Like)

## Preview

![30-second preview](Assets/Audio/nyumbani-sounds-like-saddest-truth-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/nyumbani-sounds-like-saddest-truth-lyrics.txt](Assets/Documents/nyumbani-sounds-like-saddest-truth-lyrics.txt)

```
New life is breathing all around us
New life is breathing all around us
And my time is right around the corner
I can finally see a future
For me and all my favorite people

Healing, tu-du-du-du
Tu-du-du, tu-du-du-du-du
Yeah, feeling (feeling)
Makes me want to go
I'm healing without hurting anyone
Tu-du-du (new life is), tu-du-du-du-du

New life is
Is not what you used to, you
New life is
Yeah, thank God it's meant for you (new)
Lost, make somethin' new (new life is)
Essence created by who (new)
Bystand, but I cannot lose
Céline, she gettin' every shoe (new)
Hop in, the coupe is made for two
Ten cents before I bought a view

New life is breathing all around-
(Breathing all around us)

This dream feel American (us)
This the grown-up Neverland (us)
I'm flyer than Dapper Dan (us), it's a-
It's a new life is (It's a-, it's a-)
Ain't no talk, no babblin' (us)
All them blogs is babblin' (us)

12 (right around the corner, us)
From the lowest point to the highest one (us)
I finally see the future
Remember all lights off during Christmastime (us)
I was with all my favorite people
Light the candles up (uh, tu-du-du)

Tu-du-du-du-du (light the candles up)
Tu-du-du (yeah), tu-du-du-du-du
That feeling that keeps me wanting more
I'm healing without hurting anyone
New life (without hurting anyone)
And the music, did it grow up too? (Without hurting anyone)
(Without hurting anyone)
Know what I'm sayin'?
(Without hurting anyone) (tu-du-du)
Without hurting anyone (yeah)

Tu-du-du
```

