# Eclipse feat. KayCyy

![artwork](Assets/Images/eclipse-feat-kaycyy---single-cover.jpg)

- **Album:** Eclipse feat. KayCyy - Single
- **Artist(s):** johan lenox & KayCyy
- **Released:** 2025-06-06
- **Duration:** 3:09
- **Genre:** Alternative

## Credits

- Performing artist: johan lenox & KayCyy

## Preview

![30-second preview](Assets/Audio/eclipse-feat-kaycyy-eclipse-feat-kaycyy---single-preview.m4a)

## Lyrics

_Lyrics not available._

