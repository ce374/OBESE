# Eclipse feat. KayCyy - Single

![cover](Assets/Images/eclipse-feat-kaycyy---single-cover.jpg)

- **Artist:** johan lenox & KayCyy
- **Type:** Feature
- **Released:** 2025-06-06
- **Genre:** Alternative
- **Tracks:** 1

## Track listing

1. Eclipse feat. KayCyy — 3:09
