# SUGAR&SPICE (feat. KayCyy Pluto)

![artwork](Assets/Images/interstellar-cover.jpg)

- **Album:** INTERSTELLAR
- **Artist(s):** MDJ!, 500k & nicky
- **Album artist:** MDJ! & 500k
- **Released:** 2025-03-15
- **Duration:** 4:28
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: MDJ!, 500k & nicky
- Album artist: MDJ! & 500k

## Preview

![30-second preview](Assets/Audio/sugarspice-feat-kaycyy-pluto-interstellar-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/sugarspice-feat-kaycyy-pluto-interstellar-lyrics.txt](Assets/Documents/sugarspice-feat-kaycyy-pluto-interstellar-lyrics.txt)

```
いいことないって
ぼやくばかりの毎日
No No No
変えたいなら動き出すだけ
待ってる暇はない

誰かの言ったセリフ
真に受け生きても
Nothing Blue
Good DayもBay Dayも
自分で選んだ末の答えだって
忘れちゃいない
今日も 世界は回って

SUGARみたいな甘い日々
たまに求めてみても
少しSPICEが効き過ぎた
刺激がちょうどいいのさ
Rainy days

予期せぬHappeni
見て見ぬフリじゃ退屈
No No No
すすんで乗っかって
心揺さぶられるのも悪くない

否定しないのも
否定しすぎも今時
Nothing Cool理想と現実の狭間
どこにいるべき場所があるって
信じてるのさ
今日も 探し続けてる

強いSPICEになれきって
しかめ面でいるより
SUGARの甘い魂を
思いっきり味わうのも
Rainy days

賑やか日も 孤独な夜も
心が望むそのままに
受け入れながら 抗いながら
重ねていこう

SUGARとSPICEが混ざり合い
奇跡がうまれるように
今日の苦い気持ちさえ
明日の笑顔の微
SUGARのような甘い日々
たまに求めてみても
少しSPICEが効き過ぎた刺激が
ちょうどいいのさ
Shiny days
```

