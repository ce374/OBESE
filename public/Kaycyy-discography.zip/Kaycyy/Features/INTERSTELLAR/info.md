# INTERSTELLAR

![cover](Assets/Images/interstellar-cover.jpg)

- **Artist:** MDJ! & 500k
- **Type:** Feature
- **Released:** 2025-03-15
- **Genre:** Hip-Hop/Rap
- **Tracks:** 1

## Track listing

1. SUGAR&SPICE (feat. KayCyy Pluto) — 4:28
