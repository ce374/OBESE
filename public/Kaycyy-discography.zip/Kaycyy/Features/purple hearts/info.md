# purple hearts

![cover](Assets/Images/purple-hearts-cover.jpg)

- **Artist:** MDJ!
- **Type:** Feature
- **Released:** 2025-07-15
- **Genre:** R&B/Soul
- **Tracks:** 2

## Track listing

1. trying to work (feat. KayCyy Pluto) — 3:27
2. night out (feat. kkazie & KayCyy Pluto) — 5:16
