# night out (feat. kkazie & KayCyy Pluto)

![artwork](Assets/Images/purple-hearts-cover.jpg)

- **Album:** purple hearts
- **Artist(s):** MDJ! & RAPT0R
- **Album artist:** MDJ!
- **Released:** 2025-08-07
- **Duration:** 5:16
- **Genre:** R&B/Soul

## Credits

- Performing artist: MDJ! & RAPT0R
- Album artist: MDJ!

## Preview

![30-second preview](Assets/Audio/night-out-feat-kkazie-kaycyy-pluto-purple-hearts-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/night-out-feat-kkazie-kaycyy-pluto-purple-hearts-lyrics.txt](Assets/Documents/night-out-feat-kkazie-kaycyy-pluto-purple-hearts-lyrics.txt)

```
It's a Saturday night out on the lower East side
The kids in from Queens have now taken their ride
Starlight in their eyes
Well, they're chic on the streets and they're struttin' with pride
They're light on their feet as they hustle inside
They're all giggles and sighs

The club's hot and sweaty and half of them stand
But nobody cares, it's their favorite band
They're the lost battalion from the last rebellion
Lighting the fires for the new resurrection at hand
They run to that rock and roll sound

But you're a loner and out with the crowd
And everybody knows that it's, it's kinda hard to get by
When you're so nervous and shy
You're just a loner and out with the crowd
Looking for a lover who could take you down with his heart
On your night out (on your, on your night out)
(Night out, night out, night out)
(On your night out)

There's hand-printed posters up all over the place
And it's hardly that old piano and stand-up bass
Hey, yeah, of day's gone by
'Cause the lights and the amps and the heat starts to hum
And the band's up there singing something about Kingdom Come
Kingdom Come with their guitars up high

And the room gets so sultry, it's starting to sway
That soul city street choir, man, they can play, they can play
And the night seems to answer by opening wide
And everybody's dancin'
Yeah, everybody's dancin' side-by-side
And nobody's tryin' to hide

But you, you're a loner and out with the crowd
And everybody knows that it's, it's kinda hard to get by
When you're so nervous and shy
You're just a loner and out with the crowd
Looking for a lover who could take you down with his heart
On your big night out (on your, on your night out)
(Night out, night out)
(On your night out)
```

