# trying to work (feat. KayCyy Pluto)

![artwork](Assets/Images/purple-hearts-starter-pack---ep-cover.jpg)

- **Album:** purple hearts starter pack - EP
- **Artist(s):** MDJ!
- **Released:** 2025-07-15
- **Duration:** 3:27
- **Genre:** R&B/Soul

## Credits

- Performing artist: MDJ!

## Preview

![30-second preview](Assets/Audio/trying-to-work-feat-kaycyy-pluto-purple-hearts-starter-pack--preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/trying-to-work-feat-kaycyy-pluto-purple-hearts-starter-pack--lyrics.txt](Assets/Documents/trying-to-work-feat-kaycyy-pluto-purple-hearts-starter-pack--lyrics.txt)

```
I saw you at the grocery store, I know
I should have walked over and said hello
It seemed like you were in a hurry
I didn't want to slow you down, so
I figured I should let you go

Always trying to work it out
(Work it out)
Always trying to work it out
(Work it out)

See your male children at your knees
I thought you wouldn't like to coddle us at ease
Everybody says the war is over
It isn't something you forget so easy
Saw you shipping down at the gallery

Always trying to work it out
(Work it out)
Always trying to work it out
(Work it out)
Always trying to work it out
(Work it out)
Work it out

Always trying to work it out
(Work it out)
Work it out
Always trying to work it out
(Work it out)
```

