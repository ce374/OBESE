# Tough Love (feat. Murda Beatz and KayCyy)

![artwork](Assets/Images/tarzana-cover.jpg)

- **Album:** Tarzana
- **Artist(s):** Purple Tears
- **Released:** 2023-04-21
- **Duration:** 3:34
- **Genre:** Pop

## Credits

- Performing artist: Purple Tears

## Preview

![30-second preview](Assets/Audio/tough-love-feat-murda-beatz-and-kaycyy-tarzana-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/tough-love-feat-murda-beatz-and-kaycyy-tarzana-lyrics.txt](Assets/Documents/tough-love-feat-murda-beatz-and-kaycyy-tarzana-lyrics.txt)

```
Found you lying there
With the funny look and frizzy matted hair
Dizzy-eyed and unaware
As if you've been in bed all afternoon

I saw from that moment
Your boy took you home and
I know you're not a kid no more
Now he's gone and dried up
Now you're 'bout to give up
I know what I said before

But you're fucking up
Tough love ain't enough

You'll never be in my way
The reaper came, but not today
So say it with me now
You're enough

Your mom wants you to go back
I want you to throwback
To that girl with that glow in her eyes
I saw from that moment
Your boy took you home and
I know you're not a kid no more

But you're fucking up
Tough love ain't enough

You'll never be in my way
The reaper came, but not today
So say it with me now
You're enough

Now he's gone and dried up
Now you're 'bout to give up
I know what I said before

I hope that now you see
You have much more than all your life's debris
```

