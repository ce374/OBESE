# Tarzana

![cover](Assets/Images/tarzana-cover.jpg)

- **Artist:** Purple Tears
- **Type:** Feature
- **Released:** 2023-04-21
- **Genre:** Pop
- **Tracks:** 1

## Track listing

1. Tough Love (feat. Murda Beatz and KayCyy) — 3:34
