# Hello (feat. Chlöe & KayCyy)

![artwork](Assets/Images/bible-cover.jpg)

- **Album:** B.I.B.L.E.
- **Artist(s):** Fivio Foreign
- **Released:** 2022-04-08
- **Duration:** 4:25
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: Fivio Foreign
- engineer: Tommy Rush
- engineer: Sean Solymar
- mix: Mike Dean
- performer: Chlöe
- performer: Fivio Foreign
- performer: KayCyy
- producer: AyoAA
- producer: BORDEAUX
- producer: KayCyy
- producer: MikeWavvs
- producer: Non Native
- producer: Ben “iamBNJMIIN” Thomas
- recording: Non Native
- recording: Simone Torres
- performance: Hello

## Preview

![30-second preview](Assets/Audio/hello-feat-chloe-kaycyy-bible-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/hello-feat-chloe-kaycyy-bible-lyrics.txt](Assets/Documents/hello-feat-chloe-kaycyy-bible-lyrics.txt)

```
Hello baby, hello baby

Hello baby, hello baby

Ayy, sipping that yakie, bitch in the pass' seat
Got two more in the backseat (hello baby)
'Vette all white, it's ashy
Doing 150 on the dash, can't pass me (skrr, skrr, skrr)
Go to the bank with a check like, "Cash me"
100K bitch, big rack me (big rack me)
Throw it in the bag, big bag me
I'm already married to the money, can't have me

She said she adore me
Hello, hey (hello baby)
Then I went in Dior and Dior'ed me (hello)
Drip chеck, record me (drip)
This gun on my hip a .40
If ain't about money, it borе me, I'm yawning
If ain't yak, don't pour me (don't pour me)
If ain't yak, don't pour me (uh-huh)

Come get your bitch, she on me (hello)
She clappin' her ass, applaud me (hello)
I swear I'm a son of a bitch for this sun on my wrist, uh, good morning (ooh)
And I'm the shit and this shit on my wrist a toilet, water (uh)
We in the spot, bottles and thots, took home somebody daughter (treesh)

Call me the Big Mac, bro got the big MAC
And he on point like a zig-zag (grr)
Niggas be talking that fly shit, big cap
Damn homie, where is the drip at? (Where is the drip at?)
Got this chick in the car
She complaining too much, told her, "Sit back, sit back" (sit down)
Gave her some Yak', told her relax (shh)
Boom-baow, that's how you fix that, uh (ooh)

Sipping that yakie, bitch in the pass' seat
Got two more in the backseat (hello baby)
'Vette all white, it's ashy
Doing 150 on the dash, can't pass me (skrr, skrr, skrr)
Go to the bank with a check like, "Cash me"
100K bitch, big rack me (big rack me)
Throw it in the bag, big bag me
I'm already married to the money, can't have me

Can't have me, baby (uh-huh, uh-huh, uh-huh, uh-huh)
Can't have me, baby (uh, no-no, no-no, no)
Ayy, hello baby (hello, hello, hello)
Hello baby (hello, hello, hello)

Look, huh, I'm now, y'all next
That was just something to digest (baow)
I came from the projects
And made progress (came from the projects and made progress)
Ha-ha, y'all niggas could die next (baow)
So please don't get caught in the process

Look, thotties, baddie will lick on my body, huh
I gave my shooter a Perc', huh, and now he my personal zombie, huh
I got them hitters from Barney, huh
I used to peep it in the hood
She gave me head and I nut on her hand
Like, "Fivi', you're finger licking good" (huh)

My shooter gone
I just tell him what block I want him to do it on (baow)
Yeah, he make it hot and then move it along
That little demon official (little demon official)
It's part of the day, it's part of the drizzle, huh
It was just Christmas, I gave him a pistol (Zombie on the track), baow

(Ooh) sipping that yakie, bitch in the pass' seat
Got two more in the backseat (hello baby)
'Vette all white, it's ashy
Doing 150 on the dash, can't pass me (skrr, skrr, skrr)
Go to the bank with a check like, "Cash me"
100K bitch, big rack me (big rack me)
Throw it in the bag, big bag me
I'm already married to the money, can't have me

Can't have me, baby (uh-huh, uh-huh, uh-huh, uh-huh)
Can't have me, baby (uh, no-no, no-no, no)
Ayy, hello baby (hello, hello, hello)
Hello baby (hello, hello, hello)
```

