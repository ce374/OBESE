# On God (feat. KayCyy)

![artwork](Assets/Images/bible-cover.jpg)

- **Album:** B.I.B.L.E.
- **Artist(s):** Fivio Foreign
- **Released:** 2022-04-08
- **Duration:** 3:07
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: Fivio Foreign

## Preview

![30-second preview](Assets/Audio/on-god-feat-kaycyy-bible-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/on-god-feat-kaycyy-bible-lyrics.txt](Assets/Documents/on-god-feat-kaycyy-bible-lyrics.txt)

```
Yeah, yeah
Huh, yeah, uh, huh
That's on God (that's on God)
Nigga, that's my word, look, huh (yeah, uh)
Still got my bitches from back in my day (yeah)
A nigga front, he get smacked in his face (baow)
I got rich off of sayin', "Ayy"
That was just somethin' I happen to say (huh)
And I went viral for rappin' with Ye
Take it off my waist, it go back in the safe (baow)
I don't like bitches that's actin' a way
She get out of line, she go back in her place (yeah)
I'ma self-made, huh (self-made)
Grammy-nominated (uh, yeah)
Opps know I'm not to play with (nah)
Nigga, how I'm not your favorite? (Baow)
None of them niggas don't play with my body
I see how they lookin' and hatin' on Fivi
I go get it done, I done wait on nobody
I run out of Percs, nigga, save me a molly
I don't know where you at, I'ma wait in your lobby
And I'm super sure I ain't sayin' no prolly
She wanna look better, I pay for her body
Huh, I pay for her body
The gangsters told me that I'm sanctioned (uh)
And I'm Gucci with the Haitians
She only like me when I'm naked (nah)
If she don't like me, tell her, "Fake it" (uh)
TDott dancin', he Jamaican (yeah)
They play my song on the radio station
You want me to pull up? Nigga, say your location
You say that they real, and I say that they're fakin' (huh)
That's on God
If all fails, at least we have each other
If all fails, at least we live another, yeah
And if all fails, at least we don't gotta struggle
No more, no more, yeah
If all fails, at least I got my brothers, yeah
It won't all fail, 'cause I'll see another, yeah
If things go left, God gon' redirect it
This my life, I'm gon' direct it
If all fails, at least we have each other
If all fails, at least we live another, yeah
And if all fails, at least we don't gotta struggle
No more, no more, yeah
If all fails, at least I got my brothers, yeah
It won't all fail, 'cause I see another, yeah
If things go left, God gon' redirect it
This my life, I'm gon' direct it
Huh, that's on God (that's on God)
Nigga, that's my word, look (that's my word)
It won't all fail, 'cause I'll see another
Huh, that's on God (that's on God)
Nigga, that's my word, look (that's my word)
If things go left, God gon' redirect it
Ooh, ooh, ooh, ooh, ooh, ooh
This my life, I'm gon' direct it
Huh, that's on God (that's on God)
Nigga, that's my word, look (that's my word)
Swear to God
I love TDott, bro, that's my man
Yo bro, can't stop
It's me and TDott against the world
You stupid mother fuckers
Stupid motherfucker (baow)
Baow
And this is now, this is now, woo
You came to see me at my house, nigga
It's whatever Fivi said
I just came downstairs like that, look
It's whatever Fivi said
Baow,
You heard, what Fivi said
Baow
We out side
```

