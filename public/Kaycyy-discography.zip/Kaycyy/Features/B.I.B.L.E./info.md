# B.I.B.L.E.

![cover](Assets/Images/bible-cover.jpg)

- **Artist:** Fivio Foreign
- **Type:** Feature
- **Released:** 2022-04-08
- **Genre:** Hip-Hop/Rap
- **Tracks:** 2

## Track listing

1. On God (feat. KayCyy) — 3:07
2. Hello (feat. Chlöe & KayCyy) — 4:25
