# 100 Bands

![artwork](Assets/Images/theres-a-way-feat-kaycyy---single-cover.jpg)

- **Album:** There's a Way (feat. KayCyy) - Single
- **Artist(s):** Dina Ayada
- **Released:** 2024-05-03
- **Duration:** 2:07
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: Dina Ayada

## Preview

![30-second preview](Assets/Audio/100-bands-theres-a-way-feat-kaycyy---single-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/100-bands-theres-a-way-feat-kaycyy---single-lyrics.txt](Assets/Documents/100-bands-theres-a-way-feat-kaycyy---single-lyrics.txt)

```
Count a 100 bands
Count on all my friends
With me to the end
Now I'm setting trends
Pull up in a benz
Busy holding racks
We ain't holdin hands
I be living in the future but they stuck in the past
They be screaming on my name yeah they need vocal rest
Yeah I'm famous now thats probably why they codependent
I stay up so long I'll probably never go to bed

Oh my god I be swagging
Every time I talk yeah they say they love my accent
Please forgive me god I been looking for the answers
Now I say my grace all I want is a blessing

It's on me I got it
Lost all my friends
But I still don't understand
What is beauty without you?
I got betrayed
So I don't like pretending
Don't know what they saying
But I know what imma do

Pull up with the juice do my thing like a kid yeah
In Balenci boots stepping in puddles with the drip yeah
Now they say the world is yours I could read it on a blimp
I could never lose can you please hop off my huh ahhhh

Used to call me insane
Now they treat me like Ye
Why you play with my name?
Huh
I just praise the lord
I just praise the lord yuh yuh yuh

Count a 100 bands
Count on all my friends
With me to the end
Now I'm setting trends
Pull up in a benz
Busy holding racks
We ain't holdin hands
I be living in the future but they stuck in the past
They be screaming on my name yeah they need vocal rest
Yeah I'm famous now thats probably why they codependent
I stay up so long I'll probably never go to bed

Oh my god I be swagging
Every time I talk yeah they say they love my accent
Please forgive me god I been looking for the answers
Now I say my grace all I want is a blessing
```

