# Could’ve Been Somethin’ (feat. Kaycyy Pluto)

![artwork](Assets/Images/behind-these-scars-cover.jpg)

- **Album:** Behind These Scars
- **Artist(s):** Casanova
- **Released:** 2019-10-11
- **Duration:** 3:02
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: Casanova

## Preview

![30-second preview](Assets/Audio/couldve-been-somethin-feat-kaycyy-pluto-behind-these-scars-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/couldve-been-somethin-feat-kaycyy-pluto-behind-these-scars-lyrics.txt](Assets/Documents/couldve-been-somethin-feat-kaycyy-pluto-behind-these-scars-lyrics.txt)

```
Could've Been Something

Had your love locked I don't need a key, no
You had a cold heart I brought you the heat now
And threw my torn heart you my therapy now
Don't wanna be apart I don't wanna leave now I'm all that you need now
Hoping you see yeah, you gave guarantees yeah
I don't want you turning your back on me have me wondering

Could've been something fasho (Woah,yeah)
Could've been something (Ouuuhh ouhh)
But I swear you be running from love (runnnn),
When it's obvious that I put you first (ouhhh)
Can u hold up just one second?

1st Verse:
Be my bride fuck the pride n the egos
A bite to eat? Maybe we could hit sofritos
And she don't mind hanging with my peoples
One girl bunch of guys we be looking like Cardi and the Migos
And I'm a scorp she's a leo
She's a Po
She know I trap got chicken like pio pio
And I'm flyer than a eagle
She makes me bust then I reload
Why we not together only she knows

Could've been something fasho (Woah,yeah)
Could've been something (Ouuuhh ouhh)
But I swear you be running from love (runnnn),
When it's obvious that I put you first (ouhhh)
Can u hold up just one second

2nd Verse:
Every once in a while we like to weed spark
She a sweetheart
Plus she's street smart
I learn something new whenever we talk
Can't recall a time that we fought
I'm on her once the veh's parked
And we in Guyana in front the resort
I start kissing on her neck then take her jeans off
Soon as we fly back she got a breeze off
To answer soon as he calls we could've been something

Could've been something fasho (Woah, yeah)
Could've been something (Ooo ooo)
But I swear you be running from love (runnn),
When it's obvious that I put you first (ooouu)
Can you hold up just one second
```

