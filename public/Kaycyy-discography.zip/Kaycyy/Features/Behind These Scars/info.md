# Behind These Scars

![cover](Assets/Images/behind-these-scars-cover.jpg)

- **Artist:** Casanova
- **Type:** Feature
- **Released:** 2019-10-11
- **Genre:** Hip-Hop/Rap
- **Tracks:** 1

## Track listing

1. Could’ve Been Somethin’ (feat. Kaycyy Pluto) — 3:02
