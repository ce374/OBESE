# What Happening

![artwork](Assets/Images/wdywtbwygu-cover.jpg)

- **Album:** WDYWTBWYGU
- **Artist(s):** johan lenox, KayCyy & Brooklyn Youth Chorus
- **Album artist:** johan lenox
- **Released:** 2022-05-13
- **Duration:** 2:59
- **Genre:** Alternative

## Credits

- Performing artist: johan lenox, KayCyy & Brooklyn Youth Chorus
- Album artist: johan lenox

## Preview

![30-second preview](Assets/Audio/what-happening-wdywtbwygu-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/what-happening-wdywtbwygu-lyrics.txt](Assets/Documents/what-happening-wdywtbwygu-lyrics.txt)

```
Miami!
(Hey, hey, hey, hey, hey, hey, hey, hey)
(Hey, hey, hey, hey, hey, hey, hey, hey)
(Hey, hey, hey, hey, hey, hey, hey, hey)
(Hey, hey, hey, hey, hey, hey, hey, hey)

Boom it's on, bitch nigga we gon rock your dome
Ah boom bitch what's happenin', (what? boom) bitch what's happenin'
I said boom it's on, bitch nigga we gon rock your dome
Ah boom bitch what's happenin', (what? boom) bitch what's happenin'

Hatch that pussy ass nigga why you looking at a nigga like you want to run one with me
I got my big gun with me don't feel like duking I feel like shooting for fools
And I don't like your attitude you do shit that them hoes on the rag would do
Oh faggot you better watch your mouth or I'll be in front of your house when you ask
Come out hoe bitch ass
Call another nigga dick ass, snitch ass nigga
Keep looking at a nigga like he gonna tell something
I'll fuck around and kill ya so on your mark get set get ready yo
If this shit get silly I'm letting it go home
Front street or in the front seat

You ever come my way, there's gonna be gun play
And hey I ride with the AK
Get high and spit fire at the AK
Okay
Let a nigga play and watch TDD
Knock your ass off the free seat
On my day kinda shabby boy
We drive candy toys and tote guns galore
I treat the homie like a tonka toy
And got shit you niggas ain't seen before

Boom it's on, bitch nigga we gon rock your dome
Ah boom bitch what's happenin', (what? boom boom) bitch what's happenin'
I said boom it's on, bitch nigga we gon rock your dome
Ah boom bitch what's happenin', (what? boom boom) bitch what's happenin'

Ying Yang and the T-Double-D
We, in this motherfucker crunk in this motherfucker
And our niggaz wit' a Miami boy
And I still like to play wit' my tonka toy
I'm a totally Rus kid, yes I is
You can't be serious, yes I is
You think I'm playin' then ask my brother
You see I don't believe me then ask my mother
I love my gun
I play with my gun
Have fun with my gun
I have sex with my gun
And I don't pull that motherfucker out for fun
"Cause ain't finna give your ass time to run
I'ma bust one time
Bust two times
By the third time
Your ass is mine
Hope you down for the count
He can't get up
Damn, he fallin'
He can't get up

Boom it's on, bitch nigga we gon rock your dome
Ah boom bitch what's happenin', (what? boom) bitch what's happenin'
I said boom it's on, bitch nigga we gon rock your dome
Ah boom bitch what's happenin', (what? boom) bitch what's happenin'

You a soft (motherfucker), and a fake (motherfucker)
If you mad 'cause you like you never had (motherfucker)
Fuck yo' ass (motherfucker), that's the past (motherfucker)
And I know the fact make ya mad (motherfucker)
It is what I thought nigga think it ain't
For real, you lame and we off the chain
Wit the T-Double-D, we bolo
Fuck hoes niggas ride by my Dolo
Get the keys to my car, and I jump in
Hit the Liquor store, buy my Cigars and gin
Get drunk and I'm off in the wind
Lookin' for a little itty bitty pretty that hold a sip

Big smokin', then ridin'
Don't tell nobody be quiet
Might cut it lil' butt it
Can't let this shit get ugly

Boom it's on, bitch nigga we gon rock your dome
Ah boom bitch what's happenin', (what? boom) bitch what's happenin'
I said boom it's on, bitch nigga we gon rock your dome
Ah boom bitch what's happenin', (what? boom) bitch what's happenin'

(Hey, hey, hey, hey, hey, hey, hey, hey)
(Hey, hey, hey, hey, hey, hey, hey, hey)
(Hey, hey, hey, hey, hey, hey, hey, hey)
(Hey, hey, hey, hey, hey, hey, hey, hey)

Oh my God, my God, from the south to the bottom
Trick Daddy Dollaz
Yin Yang Twins
Beat Nas
Collin Park Music Incorporated
This the next level right here
This that Krump Party
All these niggas doing this Krump Music
We Krump Party nigga
We original with it
Aye man, who really run the south?
```

