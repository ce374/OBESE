# Humble Soles

![cover](Assets/Images/humble-soles-cover.jpg)

- **Artist:** Humble Soles, DJ Clue & RJAE
- **Type:** Feature
- **Released:** 2023-08-10
- **Genre:** Hip-Hop/Rap
- **Tracks:** 1

## Track listing

1. Stuck In LA — 4:22
