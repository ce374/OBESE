# Stuck In LA

![artwork](Assets/Images/humble-soles-cover.jpg)

- **Album:** Humble Soles
- **Artist(s):** Humble Soles, KayCyy, Reuben Vincent, Guapdad 4000 & Ambré
- **Album artist:** Humble Soles, DJ Clue & RJAE
- **Released:** 2023-08-10
- **Duration:** 4:22
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: Humble Soles, KayCyy, Reuben Vincent, Guapdad 4000 & Ambré
- Album artist: Humble Soles, DJ Clue & RJAE

## Preview

![30-second preview](Assets/Audio/stuck-in-la-humble-soles-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/stuck-in-la-humble-soles-lyrics.txt](Assets/Documents/stuck-in-la-humble-soles-lyrics.txt)

```
Now it shows
How I feel
Stuck in L.A to me the sun's kind of chill

Where to go?
Where to sleep?
All of these pennies can't do nothing for me

I'm stuck in L.A
Does it get better?
It's taking forever
I'm afraid

I'm stuck in L.A
Are we still together?
We're losing each other
I'm afraid

I'm stuck in L.A
I'm stuck in L.A
It's like a dream I really want to forget

I'm stuck in L.A
I'm stuck in L.A
I still remember what I used to expect

Life's kind of slow
Daddy knows
Stuck in L.A searching for my pot of gold

Where's the rainbow?
Where's the rain?
Tell me what happened to the promise of fame

I'm stuck in L.A
I'm stuck in L.A
It's like a dream I really want to forget

I'm stuck in L.A
I'm stuck in L.A
I still remember what I used to expect

I'm stuck in L.A

I'm stuck in L.A
I'm stuck in L.A
It's like a dream I really want to forget

I'm stuck in L.A
I'm stuck in L.A
I still remember what I used to expect
I'm stuck in L.A
```

