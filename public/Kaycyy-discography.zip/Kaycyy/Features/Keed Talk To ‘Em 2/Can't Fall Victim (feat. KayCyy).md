# Can't Fall Victim (feat. KayCyy)

![artwork](Assets/Images/keed-talk-to-em-2-cover.jpg)

- **Album:** Keed Talk To ‘Em 2
- **Artist(s):** Lil Keed
- **Released:** 2023-03-17
- **Duration:** 2:53
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: Lil Keed

## Preview

![30-second preview](Assets/Audio/cant-fall-victim-feat-kaycyy-keed-talk-to-em-2-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/cant-fall-victim-feat-kaycyy-keed-talk-to-em-2-lyrics.txt](Assets/Documents/cant-fall-victim-feat-kaycyy-keed-talk-to-em-2-lyrics.txt)

```
Yeah, yeah, yeah
Yeah, you know me, um
It's Prince, nigga
Man, slime
Ayy, KayCyy
(Yeah)
Nah, I can't fall victim (yeah)
Yeah, I'm gettin' richer (no)
I can feel the symptoms (symptoms)
I'm gettin' M&Ms, and my chain got emeralds (yeah)
All these bitches poppin' out from back then
I don't remember them (Keed talk to 'em)
I just know the Culinan
I just know when I pour the syrup, I see the soda bubblin' (hey)
I just know when she shake her ass, yeah, I'm throwin' these ones, man
My mama asked me how I'm doin', I'm livin' lovely
I done sharpened up, I ain't rusty
Check every banister, it say my name for some (for some)
Yeah, the car come black and white, yeah, it look like a nun (yeah)
I told KayCyy (KayCyy), know we winnin' for some (let's go)
We ain't never losin', know it broke down, it's done (yeah)
Yeah, know I switched the whip 'cause the opp 'nem got pistol whipped
I'm just thuggin' it with Thugger, thuggin'
Play with us, it's off the hip
Shit, I been tellin' ya, now I'm puttin' you down, no, it's not a myth
We not on the same path, I took a whole different road (not on the same path, bro)
Yeah, my mama gay for real, she lovin' these hoes
I get a lot of backends, lot of backends
I'm rockin' these shows (lot of backends, lot of backends)
And my daddy showed me how to stand ten toes before the struggle (my daddy)
I be barely rockin' jewelry (yeah), but I be puttin' on these clothes (forever)
(Yeah, yeah, yeah-yeah)
Nah, I can't fall victim (yeah, yeah, yeah)
Yeah, I'm gettin' richer (no)
I can feel the symptoms (symptoms, yeah-yeah)
I'm gettin' M&Ms, and my chain got emeralds (yeah)
All these bitches poppin' out from back then
I don't remember them (Keed talk to 'em)
I just know the Culinan
I just know when I pour the syrup, I see the soda bubblin' (hey)
I just know when she shake her ass, yeah, off throwin' these ones, man
My mama asked me how I'm doin', I'm livin' lovely
I done sharpened up, I ain't rusty
Mmm, I sharpened up, I ain't rusty
Know I came from the muddy
Got both feet right out of the sand
I told them, "God did it, I ain't lucky"
Got some ego, it help with the worst
Went to they hood and made it my turf
Give and take is never enough, mm-hmm
Same ones that want me to save 'em
Where was y'all at when I needed saving?
Cut her off, I need erasing
Racks comin' in like, "Ooh-ooh"
Told mama, "Take some time off," you need it too
Told Keed, "If we can get one, we can get two"
Double up my interest, I can show you
(Yeah, yeah, yeah-yeah)
Nah, I can't fall victim (yeah, yeah, yeah)
Yeah, I'm gettin' richer (no)
I can feel the symptoms (symptoms)
I'm gettin' M&Ms, and my chain got emeralds (yeah)
All these bitches poppin' out from back then
I don't remember them (Keed talk to 'em)
I just know the Culinan
I just know when I pour the syrup, I see the soda bubblin' (hey)
I just know when she shake her ass, yeah, off throwin' these ones, man
My mama asked me how I'm doin', I'm livin' lovely
I done sharpened up, I ain't rusty
```

