# Keed Talk To ‘Em 2

![cover](Assets/Images/keed-talk-to-em-2-cover.jpg)

- **Artist:** Lil Keed
- **Type:** Feature
- **Released:** 2023-03-17
- **Genre:** Hip-Hop/Rap
- **Tracks:** 1

## Track listing

1. Can't Fall Victim (feat. KayCyy) — 2:53
