# The Script

![cover](Assets/Images/the-script-cover.jpg)

- **Artist:** Dina Ayada
- **Type:** Feature
- **Released:** 2024-05-31
- **Genre:** Hip-Hop/Rap
- **Tracks:** 1

## Track listing

1. There's a Way (feat. KayCyy) — 3:31
