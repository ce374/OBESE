# Eclipse

![artwork](Assets/Images/full-speed-nowhere-chamber-version-cover.jpg)

- **Album:** Full Speed Nowhere (Chamber Version)
- **Artist(s):** johan lenox & KayCyy
- **Album artist:** johan lenox
- **Released:** 2026-10-30
- **Duration:** 3:09
- **Genre:** Alternative

## Credits

- Performing artist: johan lenox & KayCyy
- Album artist: johan lenox

## Preview

![30-second preview](Assets/Audio/eclipse-full-speed-nowhere-chamber-version-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/eclipse-full-speed-nowhere-chamber-version-lyrics.txt](Assets/Documents/eclipse-full-speed-nowhere-chamber-version-lyrics.txt)

```
Adios le dijó el Sol al cielo
Cuando salia la luna ya
Con sus estrellas tan relumbrosas
Que todo el cielo hace brillar

Adios le dijo el Sol al cielo
Ahi te la dejo yo ya me voy
A la otra vuelta yo me la llevo
Para pasearnos juntos los dos

Adios le dijó el Sol al cielo
Cuando salia la luna ya
Con sus estrellas tan relumbrosas
Que todo el cielo hace brillar

Adios le dijo el Sol al cielo
Ahi te la dejo yo ya me voy
A la otra vuelta yo me la llevo
Para pasearnos juntos los dos

Tu eres la luna, yo soy el sol
Y si te acercas te voy a quemar
Y si te quemo te va a gustar
Muchas chispitas van a saltar

Tu eres la luna, yo soy el sol
Y si te acercas te voy a quemar
Y si te quemo te va a gustar
Muchas chispitas van a saltar

Adios le dijó el Sol al cielo
Cuando salia la luna ya
Con sus estrellas tan relumbrosas
Que todo el cielo hace brillar

Adios le dijo el Sol al cielo
Ahi te la dejo yo ya me voy
A la otra vuelta yo me la llevo
Para pasearnos juntos los dos

Tu eres la luna, yo soy el sol
Y si te acercas te voy a quemar
Y si te quemo te va a gustar
Muchas chispitas van a saltar

Tu eres la luna, yo soy el sol
Y si te acercas te voy a quemar
Y si te quemo te va a gustar
Muchas chispitas van a saltar
```

