# There's A Way (feat. KayCyy) - Single

![cover](Assets/Images/theres-a-way-feat-kaycyy---single-cover.jpg)

- **Artist:** Dina Ayada
- **Type:** Feature
- **Released:** 2024-05-31
- **Genre:** Hip-Hop
- **Tracks:** 3

## Track listing

1. There's A Way (feat. KayCyy) — 3:31
2. Hummer — 2:35
3. 100 Bands — 2:07
