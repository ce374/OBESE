# Hummer

![artwork](Assets/Images/theres-a-way-feat-kaycyy---single-cover.jpg)

- **Album:** There's A Way (feat. KayCyy) - Single
- **Artist(s):** Dina Ayada
- **Released:** 2024-05-31
- **Duration:** 2:35
- **Genre:** Hip-Hop

## Credits

- Performing artist: Dina Ayada

## Preview

![30-second preview](Assets/Audio/hummer-theres-a-way-feat-kaycyy---single-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/hummer-theres-a-way-feat-kaycyy---single-lyrics.txt](Assets/Documents/hummer-theres-a-way-feat-kaycyy---single-lyrics.txt)

```
Yeah, yeah, yeah, yeah
Huh, huh
Yeah, yeah, yeah, yeah

No, you don't need nobody, huh, huh
I know you don't wanna think about it, huh, huh
No, you don't need nobody, huh, huh
I know you're born to be somebody, huh

Ay, yeah
I was in my feelings, now I'm back, okay, huh
Riding through the hills, I'm in my bag, okay, huh
I don't really care about what they gon' say
I stay the same, huh

Ay, yeah
I was in my feelings, now I'm back, okay, huh
Riding through the hills, I'm in my bag, okay, huh
I don't really care about what they gon' say, huh
I stay the same, huh, huh

Don't know how to take it, huh
That was in the summer, huh
You was right here with me
I was riding in a Hummer, huh
Don't know how to take it, huh
Saw you like a brother, huh
Know you still my favorite
We were never for each other, huh

Back flipping, huh
Big living, huh
Always had the vision, huh
Knew that I was different, huh
Don't know how to put it, huh
Feel it in my spirit, huh
Never catch me slipping, huh
Never catch me, ugh

Headed to my bank, 'cause now I'm betting on myself, yeah
Maybe they won't get it, they don't have to understand, yeah
I just took a break, 'cause I got so much on my mind, yeah
So much on my mind, huh, so much on my, huh, huh

Dealing with the pain, huh
Know I feel the same, huh
I know you been through it
You been trying to find a way, huh
You don't need nobody
You done showed me how to fight, huh
I know you been through it
Trust me, it's gon' be alright, huh

Yeah, yeah
Huh, huh

No, you don't need nobody, huh, huh
I know you don't wanna think about it, huh, huh
No, you don't need nobody, huh, huh
I know you're born to be somebody, huh

Ay, yeah
I was in my feelings, now I'm back, okay, huh
Riding through the hills, I'm in my bag, okay, huh
I don't really care about what they gon' say
I stay the same, huh

Ay, yeah
I was in my feelings, now I'm back, okay, huh
Riding through the hills, I'm in my bag, okay, huh
I don't really care about what they gon' say, huh
I stay the same, huh

Sitting in the back, back, back
On my momma I been getting to the bag, bag, bag
Yeah, I be out here with the homies, get it back, back, back
On my momma I been getting to the bag, bag, bag, huh, huh
```

