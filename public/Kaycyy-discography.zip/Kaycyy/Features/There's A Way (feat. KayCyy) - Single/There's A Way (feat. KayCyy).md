# There's A Way (feat. KayCyy)

![artwork](Assets/Images/theres-a-way-feat-kaycyy---single-cover.jpg)

- **Album:** There's A Way (feat. KayCyy) - Single
- **Artist(s):** Dina Ayada
- **Released:** 2024-05-31
- **Duration:** 3:31
- **Genre:** Hip-Hop

## Credits

- Performing artist: Dina Ayada

## Preview

![30-second preview](Assets/Audio/theres-a-way-feat-kaycyy-theres-a-way-feat-kaycyy---single-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/theres-a-way-feat-kaycyy-theres-a-way-feat-kaycyy---single-lyrics.txt](Assets/Documents/theres-a-way-feat-kaycyy-theres-a-way-feat-kaycyy---single-lyrics.txt)

```
Yeah-ah-ah, yeah, yeah
Yeah-ah-ah, yeah, yeah

What you know? (What you know?)
I got brothers that I gotta feed
And my momma she counting on me
So I gotta go hard every day
Can't pretend (can't pretend), so I pray (so I pray)
This the life that I live every day
From the end to the start, I had faith
Thank the Lord that we living today

There's a way (there's a way)
There's a way (there's a way)
There's a way (there's a way)
There's a way
There's a way (there's a way)
There's a way (there's a way)
There's a way (there's a way)
There's a way

There's a way (there's a way)
There's a way
There's a way (there's a way)
There's a way
There's a way (there's a way)
There's a way (there's a way)
There's a way (there's a way)
There's a way

Whoa, I was figuring out where to go
I was telling my friends I don't know
What you know about being a star? (What you know?)
On the phone with my bro, he a legend
He told me, "Stay focused and you will get far"
I ain't lying, sometimes it get hard
But you know that I'm playing my part
Yeah, you know that I'm playing my part

I know I'm a star, I know I'll get far
So I'm shining my light in the dark
I grind 'til it's late, for food on our plate
Yeah, I gotta take care of the fam
Take care of my friends, they keeping me sane
I pray for the ones that I lost
I follow the love, it's never too late

I don't think that it's ever too late
I say my grace, count up my blessings
And I'm asking the Lord to forgive me
I know I got heart but can't lie I been sinning
And I'm praising the Lord, I know He protect
Hope that you know, He always give back
I just want love, God just protect
I just want love, God, please protect

What you know? (What you know?)
I got brothers that I gotta feed
And my momma she counting on me
So I gotta go hard every day
Can't pretend (can't pretend), so I pray (so I pray)
This the life that I live every day
From the end to the start, I had faith
Thank the Lord that we living today

There's a way (there's a way)
There's a way (there's a way)
There's a way (there's a way)
There's a way
There's a way (there's a way)
There's a way (there's a way)
There's a way (there's a way)
There's a way

There's a way (there's a way)
There's a way
There's a way (there's a way)
There's a way
There's a way (there's a way)
There's a way (there's a way)
There's a way (there's a way)
There's a way

Knew as a kid it was destined, it wasn't surprising (wasn't surprising at all)
Counting up all of my blessings, I see the sun rising (I see the sun rising, uh)
Don't bring up the past around me 'cause it doesn't define me, no, no
How could you say I was blind when I told you that I see, ah

Whoa, whoa, whoa, whoa
I'm loving this everyday (I am)
I put two hands together and pray (I pray)
I be pushing the pressure away
And I'm upping the price on my name
And they said I won't find me a way (they did)
And right now, hey got nothing to say (they don't)
Talked to God, and he said it's a uh (it's a uh)

There's a way (there's a way)
There's a way (there's a way)
There's a way (there's a way)
There's a way
There's a way (there's a way)
There's a way (there's a way)
There's a way (there's a way)
There's a way

There's a way (there's a way)
There's a way
There's a way (there's a way)
There's a way
There's a way (there's a way)
There's a way (there's a way)
There's a way (there's a way)
There's a way

Yeah-ah-ah-ah
Yeah-ah-ah, yeah, yeah, uhh
```

