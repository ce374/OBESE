# My Jeans - Single

![cover](Assets/Images/my-jeans---single-cover.jpg)

- **Artist:** KayCyy
- **Type:** Release
- **Released:** 2023-08-04
- **Genre:** Hip-Hop/Rap
- **Tracks:** 1

## Track listing

1. My Jeans — 2:41
