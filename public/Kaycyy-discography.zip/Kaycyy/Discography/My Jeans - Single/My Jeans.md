# My Jeans

![artwork](Assets/Images/my-jeans---single-cover.jpg)

- **Album:** My Jeans - Single
- **Artist(s):** KayCyy
- **Released:** 2023-08-04
- **Duration:** 2:41
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: KayCyy

## Preview

![30-second preview](Assets/Audio/my-jeans-my-jeans---single-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/my-jeans-my-jeans---single-lyrics.txt](Assets/Documents/my-jeans-my-jeans---single-lyrics.txt)

```
Waiting for something that I know in my heart is never gonna come
Waiting for something that I know in my heart is never gonna come
Waiting for something that I need to relieve all this pain inside

Don't tell it, nondisclosure us, yeah
Immediate closure what you want, yeah
Be mine, I don't just want a turn
Stick with me through this, you can learn, yeah

See what the mood like, yeah
Still shine in the moonlight, yeah, uh, uh, uh
Your eyes paint a picture that I've never seen, girl, yeah
I toss and turn when I think 'bout you, girl, you my dream girl
The girl of my dreams, ooh
But you make it feel real, ooh
Oh, ooh, you make it feel real
Spirits they in my team
Fire brought to the scene
Girl you rock my jeans, jeans, jeans, oh

Make it worth my while
Make me make you stay here for a while
Never out of style
Everything about you is so wild, wild

Bae, you're only sweet, I need you every single morning
I be thinkin' 'bout the things that I'ma do when we alone
I cross your mind, too, I know that you been drinking
I'll fly to Paris, yeah, you know it's time for landing

See what the mood like, yeah
Still shine in the moonlight, yeah, uh, uh, uh
Your eyes paint a picture that I've never seen, girl, yeah
I toss and turn when I think 'bout you, girl, you my dream girl
The girl of my dreams, ooh
But you make it feel real, ooh
Oh, ooh, you make it feel real
Spirits they in my team
Fire brought to the scene
Girl you rock my jeans, jeans, jeans, oh

Make it worth my while
Dun-dun-dun through my jeans
My baby
Dun-dun-dun, uh
Dun-dun-dun-dun, uh, uh, uh
```

