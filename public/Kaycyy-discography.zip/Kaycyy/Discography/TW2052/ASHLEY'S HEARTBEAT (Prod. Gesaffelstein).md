# ASHLEY'S HEARTBEAT (Prod. Gesaffelstein)

![artwork](Assets/Images/tw2052-cover.jpg)

- **Album:** TW2052
- **Artist(s):** KayCyy
- **Released:** 2023-05-26
- **Duration:** 2:08
- **Genre:** Hip-Hop/Rap

## Credits

- Producer: Gesaffelstein
- Performing artist: KayCyy
- producer: Gesaffelstein
- recording: KayCyy
- performance: ASHLEY'S HEARTBEAT

## Preview

![30-second preview](Assets/Audio/ashleys-heartbeat-prod-gesaffelstein-tw2052-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/ashleys-heartbeat-prod-gesaffelstein-tw2052-lyrics.txt](Assets/Documents/ashleys-heartbeat-prod-gesaffelstein-tw2052-lyrics.txt)

```
Not shady, sunny
Clearer, with you
Life savings, money
It's nothing with you

Bonnie, Clydin'
Not collidin', with you
Girl, come down and save me
Need you, waitin' for you
I want you to love me
But ain't beggin' for lovin', no-no
Would be cool if you loved me
We could be something, woah-woah

Pull me, down
When my thoughts, started to racin'
Don't give up, love me
Show me patience
'Cause I can love heavy, trust me
Not perfect, but I'm working on it
Slowly, holy
Trustin' that I'm making progress
Your support will be helpful
I feel like this could be special
If you down then I'm down with you
We can go, we can rendezvous
Show me all of you talents, ooh
Shawty, give me a challenge, ooh
Bring me back when I'm outta tune
Make me feel like I need you, ooh

Bonnie, Clydin'
Not collidin', with you
Girl, come down and save me
Need you, waitin' for you
I want you to love me
But ain't beggin' for lovin', no-no
Would be cool if you loved me
We could be something, woah-woah
I want you to love me
But ain't beggin' for lovin', no-no
Would be cool if you loved me
We could be something, woah-woah
```

