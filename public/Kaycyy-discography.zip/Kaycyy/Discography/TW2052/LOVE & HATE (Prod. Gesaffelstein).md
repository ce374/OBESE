# LOVE & HATE (Prod. Gesaffelstein)

![artwork](Assets/Images/tw2052-cover.jpg)

- **Album:** TW2052
- **Artist(s):** KayCyy
- **Released:** 2022-03-11
- **Duration:** 2:52
- **Genre:** Hip-Hop/Rap

## Credits

- Producer: Gesaffelstein
- Performing artist: KayCyy
- engineer: Aleksi Godard
- mix: Joe Grasso
- producer: Gesaffelstein
- recording: Joe Grasso
- performance: LOVE & HATE

## Preview

![30-second preview](Assets/Audio/love-hate-prod-gesaffelstein-tw2052-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/love-hate-prod-gesaffelstein-tw2052-lyrics.txt](Assets/Documents/love-hate-prod-gesaffelstein-tw2052-lyrics.txt)

```
Oh, you love me, you hate me, but stay with me
Hear your voice with wind when you speak to me
Speak to me, speak to me

You hate me, and love me, but lay with me
Goosebumps on your skin when you next to me
Next to me, next to me

I need you, I see you, I feel you
I need you, oh, I need you
I need you, I need you

As long as you love me enough
I will not ask for too much
Move your feet, won't keep you stuck
And show you that it's about us
```

