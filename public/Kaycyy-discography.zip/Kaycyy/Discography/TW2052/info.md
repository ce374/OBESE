# TW2052

![cover](Assets/Images/tw2052-cover.jpg)

- **Artist:** KayCyy
- **Type:** Release
- **Released:** 2022-03-11
- **Genre:** Hip-Hop/Rap
- **Tracks:** 4

## Track listing

1. ASHLEY'S HEARTBEAT (Prod. Gesaffelstein) — 2:08
2. TIMELESS (Prod. Gesaffelstein) — 3:12
3. THE SUN (Prod. Gesaffelstein) — 3:09
4. LOVE & HATE (Prod. Gesaffelstein) — 2:52
