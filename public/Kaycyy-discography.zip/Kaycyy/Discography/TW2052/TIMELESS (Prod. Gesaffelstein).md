# TIMELESS (Prod. Gesaffelstein)

![artwork](Assets/Images/tw2052-cover.jpg)

- **Album:** TW2052
- **Artist(s):** KayCyy
- **Released:** 2023-05-26
- **Duration:** 3:12
- **Genre:** Hip-Hop/Rap

## Credits

- Producer: Gesaffelstein
- Performing artist: KayCyy
- producer: Gesaffelstein
- recording: KayCyy
- performance: TIMELESS

## Preview

![30-second preview](Assets/Audio/timeless-prod-gesaffelstein-tw2052-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/timeless-prod-gesaffelstein-tw2052-lyrics.txt](Assets/Documents/timeless-prod-gesaffelstein-tw2052-lyrics.txt)

```
Stating the obvious
Quick to acknowledge you
I'm true to my promises, yeah
I'm taking the time with you
Stating the obvious, yeah
Quick to acknowledge you
True to my promises, aye-yeah
I'm taking the time with you

Don't break or fix what we make
Don't change or flip, stay the same
Got a mansion in your mind where I spend my days
Don't gotta question that I'm yours on the same page

Stating the obvious
Quick to acknowledge you (quick to acknowledge)
I'm true to my promises, yeah
I'm taking the time with you (taking the time, yeah)
Stating the obvious (obvious)
I'm taking the time with you (I'm taking the time, yeah)
Go with the hours, go with the seconds
Girl, I'm making in hours, yeah

Yeah
Taking the time with you, ah

I was in a shallow place
Almost did it, I'll admit it, I'll admit it
Temptations, almost fell in it
But I love different
Take the full sentence
I was raised different
New heights, no limits
They trust who they hate, did it
Don't break or fix what we make

Stating the obvious
Quick to acknowledge you (quick to acknowledge)
I'm true to my promises, yeah
I'm taking the time with you (time, yeah)
Stating the obvious (stating the obvious)
I'm taking the time with you (time, yeah)

Stating the obvious (ooh)
Quick to acknowledge you (quick to acknowledge)
I'm true to my promises, yeah
I'm taking the time with you (time, yeah)
Stating the obvious (stating the obvious)
I'm taking the time with you (time, yeah)
Taking the time with you (ah-ah-ah)

Stating the obvious
```

