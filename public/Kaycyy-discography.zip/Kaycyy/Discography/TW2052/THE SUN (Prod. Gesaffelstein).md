# THE SUN (Prod. Gesaffelstein)

![artwork](Assets/Images/tw2052-cover.jpg)

- **Album:** TW2052
- **Artist(s):** KayCyy
- **Released:** 2022-03-11
- **Duration:** 3:09
- **Genre:** Hip-Hop/Rap

## Credits

- Producer: Gesaffelstein
- Performing artist: KayCyy
- engineer: Aleksi Godard
- mix: Joe Grasso
- producer: Gesaffelstein
- recording: Joe Grasso
- performance: THE SUN

## Preview

![30-second preview](Assets/Audio/the-sun-prod-gesaffelstein-tw2052-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/the-sun-prod-gesaffelstein-tw2052-lyrics.txt](Assets/Documents/the-sun-prod-gesaffelstein-tw2052-lyrics.txt)

```
Oh-oh, oh-oh, yeah

I don't need the stars, the moon, the world
If you bring me the sun (yeah, uh)
I can be the spark, the start of something
That you really want

I ain't hesitate, your eyes see further
Than you really thought
And she don't need no space from me
She'll rather be where I'm at

Yeah, yeah
And I keep her all safe, yeah
I can be your art state
Rock with me on my off days, yeah
Uh, could you boost my heart rate? Mmh-mmh

Can you make the ground shake?
Yeah, can we do it for God's sake?
Can we do it from miles away?
I can make you feel the way (way)
I can give you a tidal wave
It's never raining, babe

Yeah, I don't need the stars, the moon, the world
If you bring me the sun (yeah, uh)
I can be the spark, the start of something
That you really want (baby)

I ain't hesitate, your eyes see further
Than you really thought (baby)
And she don't need no space from me
She'll rather be where I'm at

No more, ain't no more
No more nights alone, 'cause I be right there with you
Can we share the same dreams
If I be sleepin' with you?

Picture almost perfect, picture
Came from the skies, you brought a scripture
You sayin' you fly, I'm flyin' with you
If I get a minute, I spare it with you

Hmm, yeah, and you decide
Yeah, if I'm your type of guy
Yeah, open your eyes, yeah (eyes, eyes)
I can be the one you turn to

Yeah, uh, I don't need the stars, the moon, the world
If you bring me the sun (I can be the one you turn to, yeah, uh)
I can be the spark, the start of something
That you really want (be the one you turn to)

I ain't hesitate, your eyes see further
Than you really thought (I can be the one you turn to)
Yeah, she don't need no space for me
She'll rather be where I'm at (yeah, be the one you turn to)
```

