# FAR AWAY

![artwork](Assets/Images/far-away---single-cover.jpg)

- **Album:** FAR AWAY - Single
- **Artist(s):** KayCyy & Njerae
- **Album artist:** KayCyy
- **Released:** 2025-09-05
- **Duration:** 2:37
- **Genre:** Afro-Beat

## Credits

- Performing artist: KayCyy & Njerae
- Album artist: KayCyy

## Preview

![30-second preview](Assets/Audio/far-away-far-away---single-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/far-away-far-away---single-lyrics.txt](Assets/Documents/far-away-far-away---single-lyrics.txt)

```
Don't you ever get together
When you're far away, when you're far away?
The nights are long, well, it's something that you never seen
But it's hard to say, but it's hard to say

Don't listen to the words they say
They can take it or leave it anyway
Just let it go another day

Step down from the mountainside
Well, I see that you're doing fine
When you're far away, when you're far away

Well, you tell me that you're coming down
Well, it's good to see that you're back around
But it's hard to say, I was far away

Don't listen to the words they say
They could never believe you anyway
Just let it go another day

I believe that love is gonna last forever
And it's all within my mind, and it's all within my mind
I believe that love is gonna last forever
And it's all within my mind, and it's all within my mind

I believe that love is gonna last forever
And it's all within my mind, and it's all within my mind
I believe that love is gonna last forever
And it's all within my mind, and it's all within my mind

Can you believe that love is gonna last forever?
And it's all within my mind, and it's all within my mind
```

