# SEND WAVE

![artwork](Assets/Images/far-away---single-cover.jpg)

- **Album:** FAR AWAY - Single
- **Artist(s):** KayCyy
- **Released:** 2025-09-05
- **Duration:** 1:57
- **Genre:** Afro-Beat

## Credits

- Performing artist: KayCyy

## Preview

![30-second preview](Assets/Audio/send-wave-far-away---single-preview.m4a)

## Lyrics

_Lyrics not available._

