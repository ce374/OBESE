# FAR AWAY - Single

![cover](Assets/Images/far-away---single-cover.jpg)

- **Artist:** KayCyy
- **Type:** Release
- **Released:** 2025-09-05
- **Genre:** Afro-Beat
- **Tracks:** 2

## Track listing

1. FAR AWAY — 2:37
2. SEND WAVE — 1:57
