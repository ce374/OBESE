# Get Used To It

![cover](Assets/Images/get-used-to-it-cover.jpg)

- **Artist:** KayCyy
- **Type:** Release
- **Released:** 2022-06-02
- **Genre:** Hip-Hop/Rap
- **Tracks:** 3

## Track listing

1. Replay — 3:03
2. Shoutouts — 2:22
3. Hold You Up — 3:57
