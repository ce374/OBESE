# Shoutouts

![artwork](Assets/Images/get-used-to-it-cover.jpg)

- **Album:** Get Used To It
- **Artist(s):** KayCyy
- **Released:** 2022-06-02
- **Duration:** 2:22
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: KayCyy

## Preview

![30-second preview](Assets/Audio/shoutouts-get-used-to-it-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/shoutouts-get-used-to-it-lyrics.txt](Assets/Documents/shoutouts-get-used-to-it-lyrics.txt)

```
Yeah-yeah
Yeah, yeah, uh
I said, shake it for—, uh
You, me and my—
Yeah, you my, he my—
Yeah, ride for—
Shoutout to my—
You, my, me and my family, God too
God too, yeah, shoutout to my—

Prada the shoes, I paid my dues, I made the rules, uh
I milli' the check, I prayed to God, I kept my cool
Yeah, uh, made the sound, I'm shiftin' the culture, I'm addin' my twos
Yeah, like, how can I lose? These niggas can't do what I do
Yeah, shoutout to the—
Shoutout to my—, yeah
Got money in the safe, yeah, mama, we good for life
Yeah, play in more spaces, stretch the legs and walk for miles
Yeah, put my granny in a Wraith, uh, she don't even know what it is
Put my mama in a R8, to her, I'm still a lil' kid
Shoutout to my, huh
Shoutout to my family, yeah
Yeah, shoutout to my—

Yeah, they said I been ready, damn, I always think I'm petty
She just want the fetti, ain't nothing upsettin'
Spark up and forget it, shoutout to the trenches
Hope this raise their spirit
Haters, not affectin'
Told 'em it was written
Shoutout to my—, yeah

Shoutout to my—, yeah
Shoutout to my—
Shoutout to my—

Yeah, they said I been ready, damn, I always think I'm petty
She just want the fetti, ain't nothing upsettin'
Spark up and forget it, shoutout to the trenches
Hope this raise their spirit
Haters, not affectin'
Told 'em it was written
Shoutout to my-
```

