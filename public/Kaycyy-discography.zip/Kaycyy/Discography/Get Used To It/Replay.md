# Replay

![artwork](Assets/Images/get-used-to-it-cover.jpg)

- **Album:** Get Used To It
- **Artist(s):** KayCyy
- **Released:** 2022-05-27
- **Duration:** 3:03
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: KayCyy

## Preview

![30-second preview](Assets/Audio/replay-get-used-to-it-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/replay-get-used-to-it-lyrics.txt](Assets/Documents/replay-get-used-to-it-lyrics.txt)

```
Destruction, domination
14, let's go
I seen around
Hold up, Nier on different
I seen, yeah
Yeah, shit
I want more not less

Give me more, not less (More)
Give me more, not less (More)
Give me more, not less (Yeah)
Give me more, not less
Bet I do numbers, let's bet (Bet it)
Bet I do numbers, let's bet (Let's bet it)
Bet I do numbers, let's bet (Let's bet it)
I want it, yeah, yeah (Let's get it)

When I'm in the club, go straight to the DJ (Yeah)
I'm tired of domestic, can't wait to find PJs
Bitch tryna finesse and she gave me a three-way
I'm givin' out highlights
I need me a replay (Woah, yeah, yeah, yeah)

Uh, replay (Replay, ooh)
Yeah, yeah, yeah, replay
Replay (Yeah, yeah)
Replay (Oh my God)
Replay (Yeah-yeah, yeah), let's go
Replay, replay, replay, replay

Okay, I'm sensei (Yeah)
Okay (Okay)
Pay attention (Woah, attention)
Newbie in my driveway (Skrrt, skrrt)
Yeah, look both ways
Every day is payday (Payday, yeah, uh)
Mayday, you don't want war
Yeah, mayday, you don't want war (Mayday)
Yeah, mayday, they don't want war, yeah

First round pick, John Wall, yeah (Mayday)
I can make one call, yeah (One call)
Make a nigga short, feet tall (Feet tall)
Woah, the chopper six feet (Six feet)
Yeah, the chopper six feet (Six feet)
Oh yeah, the chopper six feet (Six feet)
Woah, wow, I know she gon' geek (Geek, geek)

Give me more, not less, uh (Wow)
Give me more, not less, uh (Wow)
Give me more, not less, uh (Wow)
Give me more, not less, uh
I bet I do numbers, let's bet, yeah (Let's bet it)
I bet I do numbers, let's bet, yeah (Let's bet it)
I bet I do numbers, let's bet, uh (Let's bet it)
I bet I do numbers, let's bet, uh (Let's get it)

Whatever state, I'ma find me a plug
Ain't run out fun, ain't run out of drugs
We gon' make your own trace
You gon' do what you want
I get paid for my voice so I rap when I want
I just got a new floor and bro got a new gun
Everything that we push, he try if you want

Could only afford Stüssy, now I walk in Dior
'Bout to cop a new piece and it's bright as the sun
Promise nobody book me, die if you want
I'm this year's hottest rookie, they know I'm the one
Put a nigga down six feet, pay, pay, pay
If he pay for the funds

Give me more, not less (More)
Give me more, not less (Give me more)
Give me more, not less (I need more)
I need more, not less (I see more)
I bet I do numbers, let's bet (Let's get it)
I bet I do numbers, let's bet (We can bet it)
I bet I do numbers, it's uh (We get, uh)

I stay with my dawgs like a vet, uh (Like a vet)
I stayed up all night with no rest (With no rest)
I'm uppin' the numbers instead (Oh-oh)
I had to get more, not less (Let's go)
I'm for the whole gang, got a spirit (Yeah)

They know how I'm coming (Coming, for real, yeah)
They know how I'm coming (Coming, for real, yeah)
They know how I'm coming (Coming, for real, yeah)
They know how I'm coming (Coming, for real, yeah)
Give me more, not less, uh
Give me more, not less, uh
Give me more, not less, uh
Give me more, not less, uh
Replay, replay, replay
Replay, replay, replay
Replay
```

