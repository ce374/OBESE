# Hold You Up

![artwork](Assets/Images/get-used-to-it-cover.jpg)

- **Album:** Get Used To It
- **Artist(s):** KayCyy, Annahstasia & Steven Bamidele
- **Album artist:** KayCyy
- **Released:** 2022-06-02
- **Duration:** 3:57
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: KayCyy, Annahstasia & Steven Bamidele
- Album artist: KayCyy

## Preview

![30-second preview](Assets/Audio/hold-you-up-get-used-to-it-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/hold-you-up-get-used-to-it-lyrics.txt](Assets/Documents/hold-you-up-get-used-to-it-lyrics.txt)

```
Baby, someone
Baby, sober, sober
Far away
Far away
Baby, someone

Baby, hold your ground, far from lost and found
Of course I hold you up, I'll never hold you down
Far away, far away

Yeah, I hate being unaccommodate
Get what you give, it's accommodate
Should you listen, now you accommodate
Yeah, get it all just in one day
Hey, hey, how does it feel gettin' everything?
I know you're not used to everything
You call me, I never just let it ring

I-I-I-I-I rescue you-you from the dee-ee-ee-eep
'Til we in the shallow so you can use your fee-eet
I can be your legs if you're feeling wea-eak
I mean everything I say
What's minor to you, it's major to me
If anyone serious, baby, it's me
Your wishes ain't too far from my reach

(Baby, someone)
Baby, hold your ground, far from lost and found
Of course, I hold you up, I'll never hold you down
Far away, far away
(Baby, someone)
Baby, hold your ground, far from lost and found
Of course, I hold you up, I'll never hold you down
Far away, far away

Yeah, hate being unaccommodate
I'll play by your rules on your time and day
No distractions, baby, concentrate
'Cause it all could be gone in just one day
Hey, hey, I know what I feel losin' everything
I hate to see you lose everything
When you call me, I still wanna let it ring

I-I-I-I-I rescue you-you from the dee-ee-ee-eep
'Til we in the shallow so you can use your fee-eet
I can be your legs if you're feeling wea-eak
I mean everything I say
What's minor to you, it's major to me
If anyone serious, baby, it's me
Your wishes ain't too far from my reach

(Baby, someone)
Baby, hold your ground, far from lost and found
Of course, I hold you up, I'll never hold you down
Far away, far away
(Baby, someone)
Baby, hold your ground, far from lost and found
Of course, I hold you up, I'll never hold you down
Far away (oh, oh, oh)
Far away (yeah, yeah)

Yeah, hate being unaccommodate
(Baby, someone)
Baby, hold your ground, far from lost and found
Of course, I hold you up, I'll never let you down
Far away, I'm further away, so far away
I-I-I-I-I rescue you-you from the dee-ee-ee-eep
'Til we in the shallow so you can use your fee-eet
I can be your legs if you're feeling wea-eak
(Baby, someone)
Baby, hold your ground, far from lost and found
Of course, I hold you up, I'll never hold you down (your wishes ain't too-, your wishes ain't too-)
Far away, far away
I'm all the way
```

