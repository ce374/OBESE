# Higher (feat. FFY)

![artwork](Assets/Images/higher-feat-ffy---single-cover.jpg)

- **Album:** Higher (feat. FFY) - Single
- **Artist(s):** KayCyy, EchoSlim & Nicko Rebel
- **Released:** 2023-07-27
- **Duration:** 3:10
- **Genre:** Modern Dancehall

## Credits

- Performing artist: KayCyy, EchoSlim & Nicko Rebel

## Preview

![30-second preview](Assets/Audio/higher-feat-ffy-higher-feat-ffy---single-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/higher-feat-ffy-higher-feat-ffy---single-lyrics.txt](Assets/Documents/higher-feat-ffy-higher-feat-ffy---single-lyrics.txt)

```
I started at the bottom but
I made it right on top No one
Can hold me back I'm never gonna
Stop Your love is all I need to see me
Through my day

Come closer baby,
Let me chase the fools away
Ain't nothing stopping us to
Reaching to the top Ain't nothing
Stopping us to reaching for love
Ain't nothing stopping us oooh baby
Ain't nothing stopping us from taking
Love and Higher, higher, higher Oh baby,
Higher Baby take me higher Oh-o Oh Higher
And Higher and Higher oh no take me up oh
No baby take higher oh no take Me up

Take Me higerrrrrr ain't nothing stopping
Us from reaching to the top ain't nothing
Stopping us from reaching for love ain't nothing stopping us from reaching for the sky ain't nothing stopping us from taking love and Higher, higher, higher

"Ain't nothing stopping us— Brenda Fassie

Higher, higher, higher Oh baby, higher Baby take me higher Oh-o Oh Higher and Higher and Higher Higher and Higher this is where we getting to Higher and Higher ain't nothing stopping us Higher and Higher this is where we getting to Higher and Higher ain't nothing stopping us (end)
```

