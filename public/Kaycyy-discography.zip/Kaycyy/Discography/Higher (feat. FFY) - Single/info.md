# Higher (feat. FFY) - Single

![cover](Assets/Images/higher-feat-ffy---single-cover.jpg)

- **Artist:** KayCyy, EchoSlim & Nicko Rebel
- **Type:** Release
- **Released:** 2023-07-27
- **Genre:** Modern Dancehall
- **Tracks:** 1

## Track listing

1. Higher (feat. FFY) — 3:10
