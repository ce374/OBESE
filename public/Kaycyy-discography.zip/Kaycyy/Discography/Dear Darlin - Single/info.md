# Dear Darlin - Single

![cover](Assets/Images/dear-darlin---single-cover.jpg)

- **Artist:** KayCyy Pluto
- **Type:** Release
- **Released:** 2025-02-28
- **Genre:** Country
- **Tracks:** 1

## Track listing

1. Dear Darlin — 3:22
