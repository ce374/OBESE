# Dear Darlin

![artwork](Assets/Images/dear-darlin---single-cover.jpg)

- **Album:** Dear Darlin - Single
- **Artist(s):** KayCyy Pluto
- **Released:** 2025-02-28
- **Duration:** 3:22
- **Genre:** Country

## Credits

- Performing artist: KayCyy Pluto

## Preview

![30-second preview](Assets/Audio/dear-darlin-dear-darlin---single-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/dear-darlin-dear-darlin---single-lyrics.txt](Assets/Documents/dear-darlin-dear-darlin---single-lyrics.txt)

```
Dear darlin', please excuse my writing
I can't stop my hands from shaking
'Cause I'm cold and alone tonight
And I miss you and nothing hurts like no you
And no one understands what we went through
It was short, it was swee, we tried

And if my words break through the wall
And meet you at your door
All I could say is, "Girl, I mean them all"

Dear Darlin', please excuse my writing
I can't stop my hands from shaking
'Cause I'm cold and alone tonight
I miss you and nothing hurts like no you
And no one understands what we went through
It was short, it was sweet, we tried
We tried

I understand where he's coming from

Been thinkin' about the bar we drank in
Feeling like the sofa was sinking
I was warm in the hope of your eyes

So if my words break through the wall
To meet you at your door
All I could say is, "Girl, I mean them all"

Dear darlin', please excuse my writing
I can't stop my hands from shaking
'Cause I'm cold and alone tonight
I miss you and nothing hurts like no you
And no one understands what we went through
It was short, it was sweet, we tried

Oh, I concur
These arms are yours to hold

And I miss you and nothing hurts like no you
And no one understands what we went through
It was short, it was sweet, we tried
We tried
```

