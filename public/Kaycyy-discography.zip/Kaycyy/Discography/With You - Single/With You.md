# With You

![artwork](Assets/Images/with-you---single-cover.jpg)

- **Album:** With You - Single
- **Artist(s):** KayCyy
- **Released:** 2017-02-19
- **Duration:** 3:04
- **Genre:** Afro-Pop

## Credits

- Performing artist: KayCyy

## Preview

![30-second preview](Assets/Audio/with-you-with-you---single-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/with-you-with-you---single-lyrics.txt](Assets/Documents/with-you-with-you---single-lyrics.txt)

```
Forever and ever with you, 눈감은 나의 마음에
Light me up, stars, light me up my dream
조심스레 다가왔죠
With you, be with you, need you

우연처럼 운명이 된 널
처음 본 그 순간부터 우린

Always and I, I'm gonna hold you tight
수많은 마음을 그대 주고 싶어요
시간이 흘러 멀리 닿을 수 없는
그 곳에서도, I'm with you, with you

Forever and ever with you, 셀 수 없는 그리움에
I'm thinking of you, I am missing you
추억이 내 곁에 남아
With you, be with you, need you

아주 오랜 먼 훗날 너와
마주 바라볼 수 있는 그 날

Always and I, I'm gonna hold you tight
수많은 마음을 그대 주고 싶어요
시간이 흘러 멀리 닿을 수 없는
그 곳에서도, I'm with you, with you

잃어버린 너와의 기억 새겨 둔
짙어진 별처럼 더욱 빛나기를

Always and I, I'm gonna hold you tight
날 향한 손길을 안아주고 싶어요
서로를 헤아리는 눈부신 이 밤
지금 순간을 영원히 with you
```

