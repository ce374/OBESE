# With You - Single

![cover](Assets/Images/with-you---single-cover.jpg)

- **Artist:** KayCyy
- **Type:** Release
- **Released:** 2017-02-19
- **Genre:** Afro-Pop
- **Tracks:** 1

## Track listing

1. With You — 3:04
