# Who Else Would It Be - Single

![cover](Assets/Images/who-else-would-it-be---single-cover.jpg)

- **Artist:** KayCyy
- **Type:** Release
- **Released:** 2022-11-11
- **Genre:** Hip-Hop/Rap
- **Tracks:** 1

## Track listing

1. Who Else Would It Be — 1:32
