# Who Else Would It Be

![artwork](Assets/Images/who-else-would-it-be---single-cover.jpg)

- **Album:** Who Else Would It Be - Single
- **Artist(s):** KayCyy
- **Released:** 2022-11-11
- **Duration:** 1:32
- **Genre:** Hip-Hop/Rap

## Credits

- Performing artist: KayCyy

## Preview

![30-second preview](Assets/Audio/who-else-would-it-be-who-else-would-it-be---single-preview.m4a)

## Lyrics

Lyrics stored as a document: [Assets/Documents/who-else-would-it-be-who-else-would-it-be---single-lyrics.txt](Assets/Documents/who-else-would-it-be-who-else-would-it-be---single-lyrics.txt)

```
Uh-uh, uh-uh
Uh-uh, uh-uh
Uh-uh, uh-uh
Uh-uh, uh-uh

Make my money then
Make my money on tall
Make my money be quiet, still loud when I walk
They said that it wouldn't be us
They said that it wouldn't be, uh (Yeah)
Tell me where the hell it's gon' be
Surprise, wow, we took off

I got a check in the middle of a crisis
I got hooked to a badass spice, uh
I'm 'bout to cook with some brand new spices
I gave up in the middle of me typin'
I'm like, "Bitch, you ain't worth my worth"
I said, "More ain't quench my thirst"
Another ounce how I can't preserve
Some more clothes I can't pronounce
Now, I'm free, I broke that curse
I found peace when I faced my worst
I grew and it threw me dirt
Make double in the game, either work
Hit the bank every morning, know the first

Ayy, make, make, make, uh
Make my money, don't talk (Hit the bank every morning, know)
Dejá runnin', woah (Hit the bank every morning, know the first)

Make my money, then
Make my money, don't talk (Hit the bank every morning)
Make my money be quiet, still loud when I walk (Hit the bank every morning, know the first)
They said that it wouldn't be us (Hit the bank every morning)
They said that it wouldn't be, uh
Tell me where the hell it's gon' be
Surprise, wow, we took off

Uh-uh, uh-uh
Uh-uh, uh-uh
Uh-uh, uh-uh
Uh-uh, uh-uh
```

