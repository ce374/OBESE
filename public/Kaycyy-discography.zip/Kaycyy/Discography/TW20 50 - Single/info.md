# TW20 50 - Single

![cover](Assets/Images/tw20-50---single-cover.jpg)

- **Artist:** KayCyy
- **Type:** Release
- **Released:** 2022-03-11
- **Genre:** Hip-Hop/Rap
- **Tracks:** 2

## Track listing

1. THE SUN (Prod. Gesaffelstein) — 3:09
2. LOVE & HATE (Prod. Gesaffelstein) — 2:52
